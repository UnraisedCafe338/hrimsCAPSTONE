<style>
#aiSidebar {
  position: fixed;
  top: 0;
  right: -320px; /* Hidden offscreen by default */
  width: 300px;
  height: 100%;
  background: #f1f1f1;
  border-left: 1px solid #ccc;
  padding: 10px;
  display: flex;
  flex-direction: column;
  z-index: 10000;
  box-shadow: -2px 0 5px rgba(0, 0, 0, 0.1);
  transition: right 0.4s ease-in-out;
}

#aiSidebar.active {
  right: 0;
}

  #chatArea {
    flex: 1;
    overflow-y: auto;
    margin-bottom: 10px;
    padding-right: 10px;
  }

  #userInput {
    width: 100%;
    height: 60px;
    margin-top: 10px;
    padding: 10px;
    font-size: 14px;
  }

 
  .header2 {
    font-weight: bold;
    margin-bottom: 10px;
  }
  .header2 img{
    width: 40px;
    height: 30px;
    margin-left: 5px;
    vertical-align: middle;
  }
</style>

<!-- Assistant Sidebar -->
<div id="aiSidebar" class="collapsed">
  <div class="header2"> Qutie AI <img src='../images/cutie.png'></div>
  
  <div id="chatArea"></div>

  <input type="file" id="docUpload" accept=".pdf,.docx" />
  <button onclick="uploadDocument()">Upload Document</button>

  <textarea id="userInput" placeholder="Ask the AI..."></textarea>
  <button onclick="sendToAI()" id="sendBtn">Send</button>
  <button onclick="clearChat()" style="background:#d33;">Clear Chat</button>
</div>

<script>
  function sendToAI() {
    const userInput = document.getElementById("userInput").value.trim();
    const chatArea = document.getElementById("chatArea");
    const sendBtn = document.getElementById("sendBtn");

    if (!userInput) return;

    // Show user message
    chatArea.innerHTML += `<div><strong>You:</strong> ${sanitize(userInput)}</div>`;

    // Clear input and disable button
    document.getElementById("userInput").value = "";
    sendBtn.disabled = true;
    sendBtn.textContent = "Sending...";

    // Typing indicator
    const tempMsgId = "temp-ai-msg-" + Date.now();
    chatArea.innerHTML += `<div id="${tempMsgId}"><strong>AI:</strong> <em>Typing...</em></div>`;
    chatArea.scrollTop = chatArea.scrollHeight;

    // Fetch AI response
    fetch("process_ai.php", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: "prompt=" + encodeURIComponent(userInput)
    })
    .then(response => response.text())
    .then(data => {
      document.getElementById(tempMsgId).innerHTML = `<strong>AI:</strong> ${sanitize(data)}`;
      sendBtn.disabled = false;
      sendBtn.textContent = "Send";
      chatArea.scrollTop = chatArea.scrollHeight;
    })
    .catch(error => {
      document.getElementById(tempMsgId).innerHTML = `<strong>AI:</strong> Error: ${sanitize(error)}`;
      sendBtn.disabled = false;
      sendBtn.textContent = "Send";
      chatArea.scrollTop = chatArea.scrollHeight;
    });
  }

  function sanitize(input) {
    const element = document.createElement('div');
    element.innerText = input;
    return element.innerHTML;
  }

  function uploadDocument() {
    const fileInput = document.getElementById('docUpload');
    const file = fileInput.files[0];
    const chatArea = document.getElementById("chatArea");

    if (!file) {
      alert("Please select a document.");
      return;
    }

    // Show file name in chat
    chatArea.innerHTML += `<div><strong>You:</strong> Uploaded file: ${sanitize(file.name)}</div>`;
    chatArea.scrollTop = chatArea.scrollHeight;

    const formData = new FormData();
    formData.append("resume", file);

    fetch("../handlers/upload_resume.php", {
      method: "POST",
      body: formData
    })
    .then(response => response.text())
    .then(data => {
      chatArea.innerHTML += `<div><strong>AI:</strong> Document uploaded successfully: ${sanitize(data)}</div>`;
      chatArea.scrollTop = chatArea.scrollHeight;

      // Automatically send a prompt to AI after upload
      sendToAI("The document has been uploaded. What would you like me to do with it?");
    })
    .catch(error => {
      alert("Error uploading file: " + error);
    });
}


  function clearChat() {
    document.getElementById("chatArea").innerHTML = "";
  }
</script>
