<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Virtual Filing Cabinet</title>
  <style>
    /* body {
      margin: 0;
      font-family: Arial, sans-serif;
      background-color: #eaeaea;
      display: flex;
      justify-content: center;
      padding: 40px;
    } */
    .document-button {
            background-color: #00124d;
            border-left: 4px solid #ffffff;
        }

    .cabinet {
      display: grid;
      grid-template-columns: repeat(3, 200px);
      gap: 25px;
      background: #333;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 4px 20px rgba(0,0,0,0.3);
      height: 500px;
    }
    .drawer-back {
      background: rgb(28, 28, 28);
      width: 180px;
      height: 100px;
      border: 3px solid #333;
      border-radius: 6px;
      position: relative;
      overflow: hidden;
      cursor: pointer;
      box-shadow: inset 0 0 5px rgba(255,255,255,0.05), 0 4px 10px rgba(0,0,0,0.5);
      transition: height 0.4s ease;
    }
    .drawer {
      background: #444;
      width: 180px;
      height: 100px;
      border-radius: 6px;
      position: relative;
      overflow: hidden;
      cursor: pointer;
      box-shadow: inset 0 0 5px rgba(255,255,255,0.05), 0 4px 10px rgba(0,0,0,0.5);
      transition: margin-top 0.4s ease;
      z-index:2;
    }

    .drawer::before {
      content: '';
      position: absolute;
      top: 10px;
      left: 15px;
      width: 130px;
      height: 10px;
      background: #666;
      border-radius: 5px;
    }

    .handle {
      position: absolute;
      bottom: 10px;
      left: 50%;
      transform: translateX(-50%);
      width: 60px;
      height: 8px;
      background:rgb(58, 58, 58);
      border-radius: 5px;
    }

    .label {
      position: absolute;
      top: 40%;
      left: 50%;
      transform: translate(-50%, -50%);
      color: white;
      font-size: 13px;
      font-weight: bold;
      text-align: center;
      width: 90%;
    }

    .folder-content {
      position: absolute;
      top: 30px;
      left: 5%;
      width: 80%;
      background-color: #fdd835;
      padding: 10px;
      display: flex;
      flex-direction: column;
      gap: 5px;
      opacity: 0;
      transform: translateY(-20px);
      transition: opacity 0.3s ease, transform 0.3s ease;
      z-index: 1;
    }

    .folder-content .tab {
      background: #ffe082;
      height: 15px;
      width: 80%;
      border-radius: 4px;
      margin: 2px auto;
      box-shadow: 0 2px 3px rgba(0,0,0,0.1);
    }

    /* Hover effect to "open" the drawer downward */
    .drawer-back:hover {
      height:200px;
    }

    .drawer-back:hover .folder-content {
      opacity: 1;
      transform: translateY(0);
    }
    .drawer-back:hover {
      height:200px;
    }    
    .drawer-back:hover .drawer{
      margin-top: 100px;
    }

  </style>
</head>

<body>
<?php include 'sidebar.php'; ?>
<h2 class="header">Document Management</h2><br><br><br>

<div class="content">
  
  <div class="cabinet">
    <div class="drawer-back">
      <div class="folder-content">
        <div class="tab"></div>
        <div class="tab"></div>
        <div class="tab"></div>
      </div>
    <div class="drawer">
      <div class="label">Non-Teaching Staff</div>
      <div class="handle"></div>
    </div>
    </div>

    <!-- Add more drawers as needed -->
    <div class="drawer-back">
      <div class="folder-content">
        <div class="tab"></div>
        <div class="tab"></div>
        <div class="tab"></div>
      </div>
    <div class="drawer">
      <div class="label">Senior High Faculty</div>
      <div class="handle"></div>
    </div>
    </div>

    <div class="drawer-back">
      <div class="folder-content">
        <div class="tab"></div>
        <div class="tab"></div>
        <div class="tab"></div>
      </div>
    <div class="drawer">
      <div class="label">Part-Time Faculty</div>
      <div class="handle"></div>
    </div>
    </div>
  </div>
  </div>
</body>
</html>
