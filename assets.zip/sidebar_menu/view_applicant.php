<?php
require '../vendor/autoload.php'; // Include MongoDB library
require '../connection.php';
// include 'sidebar.php';

// Connect to MongoDB
$usersCollection = $database->selectCollection("applicants"); 

// Get applicant ID from URL
$id = $_GET['id'] ?? '';
$applicant = null;

if ($id) {
    $applicant = $usersCollection->findOne(['_id' => new MongoDB\BSON\ObjectId($id)]);

    if (!$applicant) {
        die("Applicant not found.");
    }
} else {
    die("No applicant ID provided.");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Applicant Details:</title>
    <link rel="stylesheet" href="../css/form.css">
 
</head>
<?php include 'sidebar.php'; ?>

<body> 
<div class="content">
    <h2 class="header">Employment Application details:</h2><br><br><br><br>
    <div class="container">
        <div class="box-header">
            <div class="header1">
                <a href="applicants.php" class="button"> Back </a>
                <button type="button" class="button edit" onclick="toggleEdit('empform', this)">Edit</button>
            </div>
            <div class="header2">
            <div class="update-status">
                <form action="../handlers/transfer_to_employee.php" method="POST">
                    <input type="hidden" name="applicant_id" value="<?php echo (string)$id; ?>">

                    <div class="status-row">
                    <label for="status">Update Status:</label>
                    <select name="status" id="status">
                        <option value="Pending">Pending</option>
                        <option value="Hired">Hired</option>
                        <option value="Rejected">Rejected</option>
                    </select>
                    <button type="button submit" class="submit">Submit</button>
                    </div>
                </form>
                </div>

                
            </div>
        </div>
        <form action="../handlers/update_application.php" method="POST" id="empform" enctype="multipart/form-data">
        <input type="hidden" name="applicant_id" value="<?php echo $id; ?>">

        <div id="page1" class="page active">



<div class="section-container">
    <div class="box-container">
    <div class="container">

    <h3>PERSONAL INFORMATION</h3>
    <table border="1">
        <tr>
    <td>Name:</td>
      <td><input type="text" name="last_name" value="<?= $applicant['personal_info']['last_name'] ?? '' ?>" class="editable-field readonly" readonly></td>
      <td><input type="text" name="first_name" value="<?= $applicant['personal_info']['first_name'] ?? '' ?>" class="editable-field readonly" readonly></td>
      <td><input type="text" name="middle_name" value="<?= $applicant['personal_info']['middle_name'] ?? '' ?>" class="editable-field readonly" readonly></td>
    </tr>

<tr>
    <td>Residence Address:</td>
    <td colspan="3"><input type="text" name="address" value="<?= $applicant['personal_info']['address'] ?? '' ?>" class="editable-field readonly" readonly></td>
    <tr><td>Email Address:</td>
    <td colspan="3"><input type="text" name="email" value="<?= $applicant['personal_info']['email'] ?? '' ?>" class="editable-field readonly" readonly></td>

</tr>
<tr>
                    <td>Contact No.:</td>
                    <td><input type="text" name="contact_no" value="<?= $applicant['personal_info']['contact'] ?? '' ?>" class="editable-field readonly" readonly></td>
                    
                    <td>Age:</td>
                    <td><input type="text" name="age" value="<?= $applicant['personal_info']['age'] ?? '' ?>" class="editable-field readonly" readonly></td>
                <tr>
                    <td>Sex:</td>
                    <td><input type="text" name="sex" value="<?= $applicant['personal_info']['sex'] ?? '' ?>" class="editable-field readonly" readonly></td>
                    <td>Civil Status:</td>
                    <td><input type="text" name="civil_status" value="<?= $applicant['personal_info']['civil_status'] ?? '' ?>" class="editable-field readonly" readonly></td>
                </tr>
                <tr>
                    <td>Birth Date:</td>
                    <td><input type="date" name="birth_date" value="<?= $applicant['personal_info']['birth_date'] ?? '' ?>" class="editable-field readonly" readonly></td>
                    <td>Birth Place: </td>
                    <td><input type="text" name="birth_place" value="<?= $applicant['personal_info']['birth_place'] ?? '' ?>" class="editable-field readonly" readonly></td>
                </tr>
                <tr>
                    <td>Citizen:</td>
                    <td><input type="text" name="citizen" value="<?= $applicant['personal_info']['citizen'] ?? '' ?>" class="editable-field readonly" readonly></td>
                    <td>Religion:</td>
                    <td><input type="text" name="religion" value="<?= $applicant['personal_info']['religion'] ?? '' ?>" class="editable-field readonly" readonly></td>
                </tr>
                <tr>
                    <td>Height (in cm):</td>
                    <td><input type="text" name="height" value="<?= $applicant['personal_info']['height'] ?? '' ?>" class="editable-field readonly" readonly></td>
                    <td>Weight (in kg):</td>
                    <td><input type="text" name="weight" value="<?= $applicant['personal_info']['weight'] ?? '' ?>" class="editable-field readonly" readonly></td>
                </tr>
                <tr>
                    <td>Do you have any physical defects?</td>
                    <td colspan="3"><input type="text" name="physical_defects" value="<?= $applicant['personal_info']['physical_defects'] ?? '' ?>" class="editable-field readonly" readonly></td>
                </tr>
            </table>
            </div>
        
            <label>Position Applied For:</label>
            <input style="width:50%" type="text" name="position_applied"value="<?= $applicant['position_applied'] ?? '' ?>" class="editable-field readonly" readonly>
            
            <label>Desired Salary:</label>
            <input style="width:50%" type="text" name="desired_salary" value="<?= $applicant['desired_salary'] ?? '' ?>" class="editable-field readonly" readonly>
            <?php if (!empty($applicant['personal_info']['photo_id'])): ?>
                <img src="download_file.php?id=<?= $applicant['personal_info']['photo_id'] ?>" alt="2x2 Picture" width="150" />
            <?php endif; ?>
    
            </div>
            <div class="section-container">
            <div class="box-container">
            <h3>FAMILY BACKGROUND</h3>
            <table>
            <tr>
            <td><label>Father's Name:</label>
            <input type="text" name="father_name" value=" <?= $applicant['family_background']['father']['name'] ?? '' ?>" class="editable-field readonly" readonly></td>
            <td><label>Occupation:</label>
            <input type="text" name="father_occupation" value=" <?= $applicant['family_background']['father']['occupation'] ?? '' ?>" class="editable-field readonly" readonly></td>
    </tr>
            <tr>
            <td><label>Mother's Name:</label>
            <input type="text" name="mother_name" value=" <?= $applicant['family_background']['mother']['name'] ?? '' ?>" class="editable-field readonly" readonly></td>
            <td><label>Occupation:</label>
            <input type="text" name="mother_occupation" value=" <?= $applicant['family_background']['father']['occupation'] ?? '' ?>" class="editable-field readonly" readonly></td>
    </tr>
            <tr><td colspan="2"><label>Parent's Address:</label>
            <input type="text" name="parents_address" value=" <?= $applicant['family_background']['parents_address'] ?? '' ?>" class="editable-field readonly" readonly></td></tr>
            
            <tr><td><label>Spouse's Name:</label>
            <input type="text" name="spouse_name" value=" <?= $applicant['family_background']['spouse']['name'] ?? '' ?>" class="editable-field readonly" readonly></td>
            <td><label>Occupation:</label>
            <input type="text" name="spouse_occupation" value=" <?= $applicant['family_background']['spouse']['occupation'] ?? '' ?>" class="editable-field readonly" readonly></td></tr>
            </table>
            </div>
            <div class="box-container">
            <table>
            <h3>EDUCATIONAL BACKGROUND</h3>
            <tr><td><h4>School & Address</h4>
            <label>College:</label>
            <input type="text" name="college"  value=" <?= $applicant['education']['college']['school'] ?? '' ?>" class="editable-field readonly" readonly>
            
            
            <label>High School:</label>
            <input type="text" name="high_school" value=" <?= $applicant['education']['high_school']['school'] ?? '' ?>" class="editable-field readonly" readonly>
        
            
            
            <label>Elementary:</label>
            <input type="text" name="elementary" value=" <?= $applicant['education']['elementary']['school'] ?? '' ?>" class="editable-field readonly" readonly></td>
            
    

            <td><h4>Degree & Honors Received</h4>
            
            <label > &nbsp;:</label>
            <input type="text" name="college_degree" value="<?= $applicant['education']['college']['degree'] ?? '' ?>" class="editable-field readonly" readonly>
            <label> &nbsp;:</label>
            <input type="text" name="high_school_degree" value="<?= $applicant['education']['high_school']['degree'] ?? '' ?>" class="editable-field readonly" readonly>
            <label> &nbsp;:</label>
            <input type="text" name="elementary_degree" value="<?= $applicant['education']['elementary']['degree'] ?? '' ?>" class="editable-field readonly" readonly></td>

    </tr>
</table>
</div>
</div>
<div class="section-container">
<div class="box-container">
            <h3>EXPERTISE/SKILLS</h3>
            <input name="skills" value="<?= $applicant['skills'] ?? '' ?>" class="editable-field readonly" readonly></input>
            </div>
            <div class="box-container">
            <h3>EMPLOYMENT RECORD</h3>
            <label>Company & Address:</label>
            <input type="text" name="company" value="<?= $applicant['employment_history']['company'] ?? '' ?>" class="editable-field readonly" readonly>
            <label>Position:</label>
            <input type="text" name="position" value="<?= $applicant['employment_history']['position'] ?? '' ?>" class="editable-field readonly" readonly>
            <label>Reason For Leaving:</label>
            <input type="text" name="reason_for_leaving" value="<?= $applicant['employment_history']['reason_for_leaving'] ?? '' ?>" class="editable-field readonly" readonly>
            </div>
            </div>
            <div class="section-container">
            <div class="box-container">
            <h3>IMPORTANT</h3>
            <label>Person to Notify in Case of Emergency:</label>
            <input type="text" name="emergency_person" value="<?= $applicant['emergency_contact']['name'] ?? '' ?>" class="editable-field readonly" readonly>
            <label>Relationship:</label>
            <input type="text" name="emergency_relationship" value="<?= $applicant['emergency_contact']['relationship'] ?? '' ?>" class="editable-field readonly" readonly>
            <label>Address:</label>
            <input type="text" name="emergency_contact" value="<?= $applicant['emergency_contact']['emergency_address'] ?? '' ?>" class="editable-field readonly" readonly>
            <label>Contact Number:</label>
            <input type="text" name="emergency_contact" value="<?= $applicant['emergency_contact']['emergency_number'] ?? '' ?>" class="editable-field readonly" readonly>
            </div>
            <div class="box-container">
            <h3>CHARACTER REFERENCE</h3>
            <table class="table2">
                <tr>
            <td><label>Name:</label>
            <input type="text"  name="ref_name" value="<?= $applicant['character_reference']['name'] ?? '' ?>" class="editable-field readonly" readonly></td>
            <td><label>Company:</label>
            <input type="text"  name="ref_company" value="<?= $applicant['character_reference']['company'] ?? '' ?>" class="editable-field readonly" readonly></td>
</tr>
<tr>
            <td><label>Position:</label>
            <input type="text"  name="ref_position" value="<?= $applicant['character_reference']['position'] ?? '' ?>" class="editable-field readonly" readonly></td>
            <td><label>Contact No.:</label>
            <input type="text"  name="ref_contact" value="<?= $applicant['character_reference']['contact'] ?? '' ?>" class="editable-field readonly" readonly></td>
            
            
</tr>
            </table>
            </div>
            </div>
            <div class="navigation-box">
            <div class="navigation">
            <button onclick="showPage('page2')" type="button">Next</button>
        </div>
        </div>
 
            </div>
            <div id="page2" class="page">
                <div class="box-body">
                    
        <h2>Questionnaire for Applicant</h2>
<div class="question-box"> 
            <label>1. Please give a candid description of yourself as a person:</label>
            <input type="text" name="description" rows="4" value="<?= $applicant['questionnaire']['description'] ?? '' ?>" class="editable-field readonly" readonly><br><br><br><br>

            <label>2. What is your job objective and career plans for the future?</label>
            <input type="text" name="career_plans" rows="4" value="<?= $applicant['questionnaire']['career_plans'] ?? '' ?>" class="editable-field readonly" readonly><br><br><br><br>

            <label>3. Why do you want to join the teaching or office staff of EXACT Colleges of Asia?
            <input type="text" name="reason_for_joining" rows="4" value="<?= $applicant['questionnaire']['reason_for_joining'] ?? '' ?>" class="editable-field readonly" readonly><br><br><br><br>

            <label>4. Why do you think EXACT Inc. should hire you?</label>
            <input type="text" name="why_hire" rows="4" value="<?= $applicant['questionnaire']['why_hire'] ?? '' ?>" class="editable-field readonly" readonly><br><br><br><br>

            <label>5. In case you are hired, what do you expect in return from EXACT Colleges of Asia?</label>
            <input type="text" name="expectations"  value="<?= $applicant['questionnaire']['expectations'] ?? '' ?>" class="editable-field readonly" readonly><br><br>
            </div>
            </div>
            <h3>Upload Required Documents</h3>
<div class="file-upload-container">

<!-- Resume -->
<div class="file-box">
    <label class="custom-file-button">
        <input type="file" id="resumeInput" name="resume_applicant[]" multiple hidden onchange="updateFileList(this)">
        Select Files
    </label>
    <p>Resume (Applicant)</p>
    <div class="file-list" id="resumeList">
        <?php
        $docs = $applicant['documents']['resume_applicant'] ?? [];

        if (!empty($docs)) {
            try {
                require_once '../vendor/autoload.php'; // Load MongoDB if not already
                $client = new MongoDB\Client;
                $database = $client->hrims_db; // ← CHANGE this to your DB
                $filesCollection = $database->selectCollection('fs.files');

                foreach ($docs as $fileId) {
                    $file = $filesCollection->findOne([
                        '_id' => new MongoDB\BSON\ObjectId($fileId)
                    ]);

                    if ($file) {
                        $fileName = $file->filename ?? 'Unnamed File';
                        echo '<div style="margin-bottom: 8px; display: flex; align-items: center; gap: 10px;">';
                        echo '<span>' . htmlspecialchars($fileName) . '</span>';
                        echo '<a href="view_file.php?id=' . $fileId . '" target="_blank">';
                        echo '<button type="button">View</button>';
                        echo '</a>';
                        echo '</div>';
                    } else {
                        echo '<p>File not found.</p>';
                    }
                }
            } catch (Exception $e) {
                echo '<p style="color: red;">⚠ Error loading files: ' . htmlspecialchars($e->getMessage()) . '</p>';
            }
        } else {
            echo '<p>No files selected</p>';
        }
        ?>
    </div>
</div>


    <!-- Training Certificates -->
    <div class="file-box">
        <label class="custom-file-button">
            <input type="file" id="trainingInput" name="training_certificates[]" multiple hidden onchange="updateFileList(this)">
            Select Files
        </label>
        <p>Training Certificates</p>
        <div class="file-list" id="trainingList">
        <?php
        $docs = $applicant['documents']['training_certificates'] ?? [];

        if (!empty($docs)) {
            try {
                require_once '../vendor/autoload.php'; // Load MongoDB if not already
                $client = new MongoDB\Client;
                $database = $client->hrims_db; // ← CHANGE this to your DB
                $filesCollection = $database->selectCollection('fs.files');

                foreach ($docs as $fileId) {
                    $file = $filesCollection->findOne([
                        '_id' => new MongoDB\BSON\ObjectId($fileId)
                    ]);

                    if ($file) {
                        $fileName = $file->filename ?? 'Unnamed File';
                        echo '<div style="margin-bottom: 8px; display: flex; align-items: center; gap: 10px;">';
                        echo '<span>' . htmlspecialchars($fileName) . '</span>';
                        echo '<a href="view_file.php?id=' . $fileId . '" target="_blank">';
                        echo '<button type="button">View</button>';
                        echo '</a>';
                        echo '</div>';
                    } else {
                        echo '<p>File not found.</p>';
                    }
                }
            } catch (Exception $e) {
                echo '<p style="color: red;">⚠ Error loading files: ' . htmlspecialchars($e->getMessage()) . '</p>';
            }
        } else {
            echo '<p>No files selected</p>';
        }
        ?>
        </div>
    </div>

    <!-- Diploma -->
    <div class="file-box">
        <label class="custom-file-button">
            <input type="file" id="diplomaInput" name="diploma[]" multiple hidden onchange="updateFileList(this)">
            Select Files
        </label>
        <p>Diploma</p>
        <div class="file-list" id="diplomaList">
        <?php
        $docs = $applicant['documents']['diploma'] ?? [];

        if (!empty($docs)) {
            try {
                require_once '../vendor/autoload.php'; // Load MongoDB if not already
                $client = new MongoDB\Client;
                $database = $client->hrims_db; // ← CHANGE this to your DB
                $filesCollection = $database->selectCollection('fs.files');

                foreach ($docs as $fileId) {
                    $file = $filesCollection->findOne([
                        '_id' => new MongoDB\BSON\ObjectId($fileId)
                    ]);

                    if ($file) {
                        $fileName = $file->filename ?? 'Unnamed File';
                        echo '<div style="margin-bottom: 8px; display: flex; align-items: center; gap: 10px;">';
                        echo '<span>' . htmlspecialchars($fileName) . '</span>';
                        echo '<a href="view_file.php?id=' . $fileId . '" target="_blank">';
                        echo '<button type="button">View</button>';
                        echo '</a>';
                        echo '</div>';
                    } else {
                        echo '<p>File not found.</p>';
                    }
                }
            } catch (Exception $e) {
                echo '<p style="color: red;">⚠ Error loading files: ' . htmlspecialchars($e->getMessage()) . '</p>';
            }
        } else {
            echo '<p>No files selected</p>';
        }
        ?>
        </div>
    </div>

    <!-- Contracts -->
    <div class="file-box">
        <label class="custom-file-button">
            <input type="file" id="contractsInput" name="contracts[]" multiple hidden onchange="updateFileList(this)">
            Select Files
        </label>
        <p>Contracts</p>
        <div class="file-list" id="contractsList">
        <?php
        $docs = $applicant['documents']['contracts'] ?? [];

        if (!empty($docs)) {
            try {
                require_once '../vendor/autoload.php'; // Load MongoDB if not already
                $client = new MongoDB\Client;
                $database = $client->hrims_db; // ← CHANGE this to your DB
                $filesCollection = $database->selectCollection('fs.files');

                foreach ($docs as $fileId) {
                    $file = $filesCollection->findOne([
                        '_id' => new MongoDB\BSON\ObjectId($fileId)
                    ]);

                    if ($file) {
                        $fileName = $file->filename ?? 'Unnamed File';
                        echo '<div style="margin-bottom: 8px; display: flex; align-items: center; gap: 10px;">';
                        echo '<span>' . htmlspecialchars($fileName) . '</span>';
                        echo '<a href="view_file.php?id=' . $fileId . '" target="_blank">';
                        echo '<button type="button">View</button>';
                        echo '</a>';
                        echo '</div>';
                    } else {
                        echo '<p>File not found.</p>';
                    }
                }
            } catch (Exception $e) {
                echo '<p style="color: red;">⚠ Error loading files: ' . htmlspecialchars($e->getMessage()) . '</p>';
            }
        } else {
            echo '<p>No files selected</p>';
        }
        ?>
        </div>
    </div>

    <!-- Transcript of Records -->
    <div class="file-box">
        <label class="custom-file-button">
            <input type="file" id="torInput" name="transcript_of_records[]" multiple hidden onchange="updateFileList(this)">
            Select Files
        </label>
        <p>Transcript of Records (Bachelor, Masteral, and PhD)</p>
        <div class="file-list" id="torList">
        <?php
        $docs = $applicant['documents']['transcript_of_records'] ?? [];

        if (!empty($docs)) {
            try {
                require_once '../vendor/autoload.php'; // Load MongoDB if not already
                $client = new MongoDB\Client;
                $database = $client->hrims_db; // ← CHANGE this to your DB
                $filesCollection = $database->selectCollection('fs.files');

                foreach ($docs as $fileId) {
                    $file = $filesCollection->findOne([
                        '_id' => new MongoDB\BSON\ObjectId($fileId)
                    ]);

                    if ($file) {
                        $fileName = $file->filename ?? 'Unnamed File';
                        echo '<div style="margin-bottom: 8px; display: flex; align-items: center; gap: 10px;">';
                        echo '<span>' . htmlspecialchars($fileName) . '</span>';
                        echo '<a href="view_file.php?id=' . $fileId . '" target="_blank">';
                        echo '<button type="button">View</button>';
                        echo '</a>';
                        echo '</div>';
                    } else {
                        echo '<p>File not found.</p>';
                    }
                }
            } catch (Exception $e) {
                echo '<p style="color: red;">⚠ Error loading files: ' . htmlspecialchars($e->getMessage()) . '</p>';
            }
        } else {
            echo '<p>No files selected</p>';
        }
        ?>
        </div>
    </div>

</div>
</div>
<!-- Navigation Buttons -->
<div class="navigation-box">
    <div class="navigation">
        <button onclick="showPage('page1')" type="button">Previous</button>
        <button type="submit">Submit</button>
    </div>
</div>

</form>

    </div>
    
</div>
</body>
</html>
<script>
        function showPage(pageId) {
            document.querySelectorAll('.page').forEach(page => {
                page.classList.remove('active');
            });
            document.getElementById(pageId).classList.add('active');
        }
        function updateFileName(input) {
    let fileNameContainer = input.closest('.upload-box').querySelector('.file-name');
    let removeButton = input.closest('.upload-box').querySelector('.remove-file');

    let fileNames = [];
    for (let i = 0; i < input.files.length; i++) {
        fileNames.push(input.files[i].name);
    }

    if (fileNames.length > 0) {
        fileNameContainer.textContent = fileNames.join(", ");
        removeButton.style.display = 'inline-block';
    } else {
        fileNameContainer.textContent = "";
        removeButton.style.display = 'none';
    }
}

function toggleEdit(formId, button) {
  const form = document.getElementById(formId);
  const fields = form.querySelectorAll('.editable-field');

  if (fields.length === 0) {
    console.warn("No editable fields found in form:", formId);
    return;
  }

  const isReadOnly = fields[0].hasAttribute("readonly");

  fields.forEach(field => {
    if (isReadOnly) {
      field.removeAttribute("readonly");
      field.classList.remove("readonly");
    } else {
      field.setAttribute("readonly", true);
      field.classList.add("readonly");
    }
  });

  button.textContent = isReadOnly ? 'Save' : 'Edit';
}

    </script>