<?php
require '../vendor/autoload.php'; // Include MongoDB library
require '../connection.php';
// include 'sidebar.php';

// Connect to MongoDB
$usersCollection = $database->selectCollection("employee"); 

// Get applicant ID from URL
$id = $_GET['id'] ?? '';
$applicant = null;

if ($id) {
    $applicant = $usersCollection->findOne(['_id' => new MongoDB\BSON\ObjectId($id)]);

    if (!$applicant) {
        die("Applicant not found.");
    }
} else {
    die("No applicant ID provided.");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Details:</title>
    <style>
        .employee-button {
        background-color: #00124d;
        border-left: 4px solid #ffffff;
        }
.editable-field.readonly {
  background-color: #f0f0f0;
  border: none;
  color: #555;
  pointer-events: none; /* Prevent clicking */
}

.editable-field {
  background-color: white;
  border: 1px solid #ccc;
  color: black;
  pointer-events: auto;
}
    .toggle-button {
      margin-top: 20px;
    }
                body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        .container {
            width: 100%;
            margin: auto;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            border: 0px;
        }
        td {
            padding: 5px;
        }
        input, select {
            width: 97%;
            padding: 5px;
            margin: 3px 0;
            }
        textarea {
            width: 99%;
            height: 100%;
            max-height: 140px;
            padding: 5px;
        }
        .submit-btn {
                text-align: center;
                margin-top: 110px;
        }
        .submit-btn button {
    background-color: #00124d;
    color: white;
    padding: 15px 30px; 
    font-size: 1.5rem; 
    font-weight: bold;
    border: none;
    border-radius: 10px;
    cursor: pointer;
    width: 30%; 
    min-width: 200px; 
    max-width: 400px; 
    height: auto;
    min-height: 60px; 
    transition: 0.3s ease-in-out;
}
.submit-btn button:hover {
    background-color: #003080;
    transform: scale(1.05);
}
        .section-container {
    display: flex;
    justify-content: space-between;
    gap: 20px;
}
.section-container .box-container:nth-child(2) {
    display: flex;
    flex-direction: column; 
    min-height: 250px; /* Adjust if necessary */
    padding: 15px;
    padding-top: 1px;
    justify-content: start;
}
.section {
    width: 48%;
    background-color: #f8f9fa; /* Light background */
    padding: 15px;
    border-radius: 8px;
    box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
}
.box-container {
    background-color: #f8f9fa;
    width: 100% ;
    padding: 15px;
    margin-bottom: 20px;
    border-radius: 8px;
    box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
    border: 1px solid #ddd;
    max-width: 100%;
    padding-top: 1px;
}
.box-container1 {
    display: flex;
    flex-direction: column;
    justify-content: flex-end;
    background-color: #f8f9fa;
    width: 100%;
    padding: 15px;
    margin-top: 13.5rem;
    height: 230px;
    /* margin-bottom: 20px; */
    border-radius: 8px;
    box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
    border: 1px solid #ddd;
}



.text-aera {
    resize: vertical;
    overflow-y: auto;  
}
.type-box {
    max-width: 40%;
}
.navigation-box{
    width: 100%;
}
.page {
            display: none;
            padding-bottom: 80px;
        }
        .active {
            display: block;
        }
.navigation {
            text-align: center;
            margin-top: 20px;
            position: fixed;
            bottom: 0px;
            right: 0px;
            padding: 15px 25px;
            border: 2px solid #000;
            border-radius: 10px;
            margin-bottom: 40px;
            background-color: #f8f9fa;
            gap: 20px;
        }
        .navigation button {
    background-color: #00124d;
    color: white;
    padding: 15px 30px; /* Bigger padding */
    font-size: 1rem; /* Larger font */
    font-weight: bold;
    border: none;
    border-radius: 10px;
    cursor: pointer;
    width: 20%; /* Responsive width */
    min-width: 120px; /* Ensures it doesn’t get too small */
    max-width: 400px; /* Prevents it from becoming too big */
    height: auto;
    min-height: 50px; /* Larger height */
    transition: 0.3s ease-in-out;
    
        }
        .navigation button:hover {
            background-color: #003080;
        }


.file-upload-container {
    display: grid;
    grid-template-columns: repeat(5, minmax(120px, 1fr)); /* Always 5 columns */
    justify-content: center;
    width: 100%; /* Takes most of the available space */
    margin: 0 auto; /* Centers the grid */
    transform: translateX(-10px); /* Moves it slightly to the left */
    border: 2px solid black;
    border-radius: 10px;
    gap: 10px;
    padding-left: 20px;
    padding-top: 20px;
    padding-right: 20px;
}

/* Make the label look like a button */
.upload-box label {
    display: inline-block;
    background-color: #00124d;
    color: white;
    padding: 10px 15px;
    font-size: 14px;
    font-weight: bold;
    border-radius: 5px;
    cursor: pointer;
    transition: 0.3s ease-in-out;
    width: 85%;
    text-align: center;
}


/* Hover effect for the upload button */
.upload-box label:hover {
    background-color: #003080;
    transform: scale(1.05);
}

/* Ensure input is always functional but hidden */
.upload-box input[type="file"] {
    opacity: 0;
    position: absolute;
    width: 0;
    height: 0;
}

.box-container1 {
    display: flex;
    flex-direction: column;
    justify-content: flex-start;
    background-color: #f8f9fa;
    width: 100%;
    padding: 15px;
    margin-top: 13.5rem;
    height: 230px;
    border-radius: 8px;
    box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.2);
    border: 1px solid #ddd;
    position: relative; /* Ensure the upload box is positioned relative to this container */
}

.upload-container {
    position: absolute;
    top: 15px; /* Adjust distance from top */
    right: 15px; /* Always stay in the right corner */
}

.upload-box {
    width: 206px;
    height: 206px;
    border: 2px dashed #ccc;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    cursor: pointer;
    background-size: cover;
    background-position: center;
    text-align: center;
    color: #666;
}

        .upload-box:hover {
            border-color: #007bff;
        }

        .upload-box span {
            position: absolute;
            font-size: 14px;
            text-align: center;
            width: 100%;
        }

        input[type="file"] {
            display: none;
        }
        .question-box{
            width: 100%;
            max-width: 98%;
            text-align: left;
        }
        .question-box label {
    font-size: 1.5rem; /* Makes the font bigger */
    font-weight: normal; /* Makes it more readable */
    display: block; /* Ensures labels are on a new line */
    margin-bottom: 10px; /* Adds space between questions */
}
        #character_reference {
    max-width: 350px; /* Adjust the width as needed */
    width: 100%; /* Ensures it is responsive */
    border: 0.5px solid #000; /* Adds a solid black border */
    outline: none; /* Ensures no extra outline when clicked */
    border-radius: 4px; /* Optional: Rounds the edges slightly */
    padding: 5px;
    margin: 3px 0;
}
.table2 {
    width: 100%;
    border-collapse: collapse;
}

.table2 td {
    padding: 8px 15px;
    vertical-align: top;
}

.table2 label {
    display: block; /* Moves the label above the input */
    font-weight: normal; /* Makes the labels stand out */
    margin-bottom: 3px;
}

.table2 input {
    width: 97%;
            padding: 5px;
            margin: 3px 0;
}
.box-body {

}
/* Add border around each file-box */
.file-box {
  border: 2px solid rgb(8, 10, 12); /* Blue border (adjust color and size as needed) */
  padding: 20px; /* Add padding inside the border */
  border-radius: 8px; /* Optional: for rounded corners */
  margin-bottom: 20px; /* Optional: space between boxes */
}

.file-box label {
  display: block;
  position: relative;
  background-color: #025bee;
  color: #ffffff;
  font-size: 1.12em;
  font-weight: 500;
  text-align: center;
  padding: 1.12em 0;
  margin: auto;
  border-radius: 0.31em;
  cursor: pointer;
  width: 100%; /* Remove fixed width */
  height: auto;
  
}

/* Optionally, add hover effect */
.file-box label:hover {
  background-color: #1a75d1; /* Slightly darker blue */
}

/* Hide the default file input */
.file-box input[type="file"] {
  display: none;
}
.file-box p {
  text-align: center;
  margin-top: 10px; /* Add some space above the text */
}

/* .file-upload-container {
        text-align: center;
        background: #f8f9fa;
        padding: 20px;
        border-radius: 10px;
        width: 400px;
        margin: auto;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
    } */

    .custom-file-button {
        display: inline-block;
        padding: 10px 20px;
        background: #007bff;
        color: white;
        font-weight: bold;
        border-radius: 5px;
        cursor: pointer;
    }

    .custom-file-button:hover {
        background: #0056b3;
    }

    input[type="file"] {
        display: none;
    }

    .file-box {
        margin-top: 15px;
        padding: 10px;
        background: white;
        border-radius: 5px;
    }

    .file-list {
        margin-top: 10px;
        padding: 10px;
        background: #ffffff;
        border-radius: 5px;
        max-height: 200px;
        overflow-y: auto;
    }

    .file-item {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 8px;
        border-bottom: 1px solid #ddd;
    }

    .file-item:last-child {
        border-bottom: none;
    }

    .file-name {
        font-weight: bold;
        max-width: 250px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
    }

    .file-size {
        color: gray;
        margin-left: 10px;
    }

    .remove-file {
        background: none;
        border: none;         
        cursor: pointer;
        font-size: 16px;
        color: red;
    }
    .button{
        
    }
    .update-status {
        max-width: 800px;
        margin: 0px auto;
        padding: 15px ;
        background: #f9f9f9;
        border: 0px solid #ddd;
        border-radius: 10px;
        font-family: Arial, sans-serif;
        }

        .status-row {
        display: flex;
        align-items: center;
        gap: 10px; /* space between elements */
        }

        .status-row label {
        font-weight: bold;
        }

        .status-row select {
        padding: 8px 12px;
        border: 1px solid #ccc;
        border-radius: 6px;
        }

        .submit {
        padding: 8px 16px;
        background-color: #3498db;
        color: #fff;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        transition: background-color 0.2s ease;
        }

        button.submit:hover {
        background-color: #2980b9;
        }
    </style>
</head>
<?php include 'sidebar.php'; ?>

<body> 
<div class="content">
<h2 class="header">Employment Application Form</h2><br><br><br><br>
<div class="container">
<div class="box-header">
<button type="button" class="button" onclick="toggleEdit('empform', this)">Edit</button>
<form action="transfer_to_employee.php" method="POST">
    <input type="hidden" name="applicant_id" value="<?php echo (string)$id; ?>">
    <label for="status">Update Status:</label>
    <select name="status" id="status">
        <option value="Hired">Hired</option>
        <option value="Rejected">Rejected</option>
    </select>

    <button type="submit">Submit</button>
</form>

        </div>
        <form action="update_application.php" method="POST" id="empform" enctype="multipart/form-data">
        <input type="hidden" name="applicant_id" value="<?php echo $id; ?>">

        <div id="page1" class="page active">



    <div class="section-container">
            <div class="box-container">

            <h3>PERSONAL INFORMATION</h3>
            <table border="1">
                <tr>
                    <td>Name:</td>

    



        
      <td><input type="text" name="last_name" value="<?= $applicant['personal_info']['last_name'] ?? '' ?>" class="editable-field readonly" readonly></td>
      <td><input type="text" name="first_name" value="<?= $applicant['personal_info']['first_name'] ?? '' ?>" class="editable-field readonly" readonly></td>
      <td><input type="text" name="middle_name" value="<?= $applicant['personal_info']['middle_name'] ?? '' ?>" class="editable-field readonly" readonly></td>
    </tr>

                <tr>
                    <td>Residence Address:</td>
                    <td colspan="3"><input type="text" name="address" value="<?= $applicant['personal_info']['address'] ?? '' ?>" class="editable-field readonly" readonly></td>
                    <tr><td>Email Address:</td>
                    <td colspan="3"><input type="text" name="email" value="<?= $applicant['personal_info']['email'] ?? '' ?>" class="editable-field readonly" readonly></td>

                </tr>
                <tr>
                    <td>Contact No.:</td>
                    <td><input type="text" name="contact_no" value="<?= $applicant['personal_info']['contact'] ?? '' ?>" class="editable-field readonly" readonly></td>
                    
                    <td>Age:</td>
                    <td><input type="text" name="age" value="<?= $applicant['personal_info']['age'] ?? '' ?>" class="editable-field readonly" readonly></td>
                <tr>
                    <td>Sex:</td>
                    <td><input type="text" name="sex" value="<?= $applicant['personal_info']['sex'] ?? '' ?>" class="editable-field readonly" readonly></td>
                    <td>Civil Status:</td>
                    <td><input type="text" name="civil_status" value="<?= $applicant['personal_info']['civil_status'] ?? '' ?>" class="editable-field readonly" readonly></td>
                </tr>
                <tr>
                    <td>Birth Date:</td>
                    <td><input type="date" name="birth_date" value="<?= $applicant['personal_info']['birth_date'] ?? '' ?>" class="editable-field readonly" readonly></td>
                    <td>Birth Place: </td>
                    <td><input type="text" name="birth_place" value="<?= $applicant['personal_info']['birth_place'] ?? '' ?>" class="editable-field readonly" readonly></td>
                </tr>
                <tr>
                    <td>Citizen:</td>
                    <td><input type="text" name="citizen" value="<?= $applicant['personal_info']['citizen'] ?? '' ?>" class="editable-field readonly" readonly></td>
                    <td>Religion:</td>
                    <td><input type="text" name="religion" value="<?= $applicant['personal_info']['religion'] ?? '' ?>" class="editable-field readonly" readonly></td>
                </tr>
                <tr>
                    <td>Height (in cm):</td>
                    <td><input type="text" name="height" value="<?= $applicant['personal_info']['height'] ?? '' ?>" class="editable-field readonly" readonly></td>
                    <td>Weight (in kg):</td>
                    <td><input type="text" name="weight" value="<?= $applicant['personal_info']['weight'] ?? '' ?>" class="editable-field readonly" readonly></td>
                </tr>
                <tr>
                    <td>Do you have any physical defects?</td>
                    <td colspan="3"><input type="text" name="physical_defects" value="<?= $applicant['personal_info']['physical_defects'] ?? '' ?>" class="editable-field readonly" readonly></td>
                </tr>
            </table>
            </div>
            <div class="box-container1">
            <label>Position Applied For:</label>
            <input style="width:50%" type="text" name="position_applied"value="<?= $applicant['position_applied'] ?? '' ?>" class="editable-field readonly" readonly>
            
            <label>Desired Salary:</label>
            <input style="width:50%" type="text" name="desired_salary" value="<?= $applicant['desired_salary'] ?? '' ?>" class="editable-field readonly" readonly>
            <?php if (!empty($applicant['personal_info']['photo_id'])): ?>
                <img src="download_file.php?id=<?= $applicant['personal_info']['photo_id'] ?>" alt="2x2 Picture" width="150" />
            <?php endif; ?>
    </div>
            </div>
            <div class="section-container">
            <div class="box-container">
            <h3>FAMILY BACKGROUND</h3>
            <table>
            <tr>
            <td><label>Father's Name:</label>
            <input type="text" name="father_name" value=" <?= $applicant['family_background']['father']['name'] ?? '' ?>" class="editable-field readonly" readonly></td>
            <td><label>Occupation:</label>
            <input type="text" name="father_occupation" value=" <?= $applicant['family_background']['father']['occupation'] ?? '' ?>" class="editable-field readonly" readonly></td>
    </tr>
            <tr>
            <td><label>Mother's Name:</label>
            <input type="text" name="mother_name" value=" <?= $applicant['family_background']['mother']['name'] ?? '' ?>" class="editable-field readonly" readonly></td>
            <td><label>Occupation:</label>
            <input type="text" name="mother_occupation" value=" <?= $applicant['family_background']['father']['occupation'] ?? '' ?>" class="editable-field readonly" readonly></td>
    </tr>
            <tr><td colspan="2"><label>Parent's Address:</label>
            <input type="text" name="parents_address" value=" <?= $applicant['family_background']['parents_address'] ?? '' ?>" class="editable-field readonly" readonly></td></tr>
            
            <tr><td><label>Spouse's Name:</label>
            <input type="text" name="spouse_name" value=" <?= $applicant['family_background']['spouse']['name'] ?? '' ?>" class="editable-field readonly" readonly></td>
            <td><label>Occupation:</label>
            <input type="text" name="spouse_occupation" value=" <?= $applicant['family_background']['spouse']['occupation'] ?? '' ?>" class="editable-field readonly" readonly></td></tr>
            </table>
            </div>
            <div class="box-container">
            <table>
            <h3>EDUCATIONAL BACKGROUND</h3>
            <tr><td><h4>School & Address</h4>
            <label>College:</label>
            <input type="text" name="college"  value=" <?= $applicant['education']['college']['school'] ?? '' ?>" class="editable-field readonly" readonly>
            
            
            <label>High School:</label>
            <input type="text" name="high_school" value=" <?= $applicant['education']['high_school']['school'] ?? '' ?>" class="editable-field readonly" readonly>
        
            
            
            <label>Elementary:</label>
            <input type="text" name="elementary" value=" <?= $applicant['education']['elementary']['school'] ?? '' ?>" class="editable-field readonly" readonly></td>
            
    

            <td><h4>Degree & Honors Received</h4>
            
            <label > &nbsp;:</label>
            <input type="text" name="college_degree" value="<?= $applicant['education']['college']['degree'] ?? '' ?>" class="editable-field readonly" readonly>
            <label> &nbsp;:</label>
            <input type="text" name="high_school_degree" value="<?= $applicant['education']['high_school']['degree'] ?? '' ?>" class="editable-field readonly" readonly>
            <label> &nbsp;:</label>
            <input type="text" name="elementary_degree" value="<?= $applicant['education']['elementary']['degree'] ?? '' ?>" class="editable-field readonly" readonly></td>

    </tr>
</table>
</div>
</div>
<div class="section-container">
<div class="box-container">
            <h3>EXPERTISE/SKILLS</h3>
            <input name="skills" value="<?= $applicant['skills'] ?? '' ?>" class="editable-field readonly" readonly></input>
            </div>
            <div class="box-container">
            <h3>EMPLOYMENT RECORD</h3>
            <label>Company & Address:</label>
            <input type="text" name="company" value="<?= $applicant['employment_history']['company'] ?? '' ?>" class="editable-field readonly" readonly>
            <label>Position:</label>
            <input type="text" name="position" value="<?= $applicant['employment_history']['position'] ?? '' ?>" class="editable-field readonly" readonly>
            <label>Reason For Leaving:</label>
            <input type="text" name="reason_for_leaving" value="<?= $applicant['employment_history']['reason_for_leaving'] ?? '' ?>" class="editable-field readonly" readonly>
            </div>
            </div>
            <div class="section-container">
            <div class="box-container">
            <h3>IMPORTANT</h3>
            <label>Person to Notify in Case of Emergency:</label>
            <input type="text" name="emergency_person" value="<?= $applicant['emergency_contact']['name'] ?? '' ?>" class="editable-field readonly" readonly>
            <label>Relationship:</label>
            <input type="text" name="emergency_relationship" value="<?= $applicant['emergency_contact']['relationship'] ?? '' ?>" class="editable-field readonly" readonly>
            <label>Address & Contact Number:</label>
            <input type="text" name="emergency_contact" value="<?= $applicant['emergency_contact']['emergency_contact'] ?? '' ?>" class="editable-field readonly" readonly>
            </div>
            <div class="box-container">
            <h3>CHARACTER REFERENCE</h3>
            <table class="table2">
                <tr>
            <td><label>Name:</label>
            <input type="text"  name="ref_name" value="<?= $applicant['character_reference']['name'] ?? '' ?>" class="editable-field readonly" readonly></td>
            <td><label>Company:</label>
            <input type="text"  name="ref_company" value="<?= $applicant['character_reference']['company'] ?? '' ?>" class="editable-field readonly" readonly></td>
</tr>
<tr>
            <td><label>Position:</label>
            <input type="text"  name="ref_position" value="<?= $applicant['character_reference']['position'] ?? '' ?>" class="editable-field readonly" readonly></td>
            <td><label>Contact No.:</label>
            <input type="text"  name="ref_contact" value="<?= $applicant['character_reference']['contact'] ?? '' ?>" class="editable-field readonly" readonly></td>
            
            
</tr>
            </table>
            </div>
            </div>
            <div class="navigation-box">
            <div class="navigation">
            <button onclick="showPage('page2')" type="button">Next</button>
        </div>
        </div>
 
            </div>
            <div id="page2" class="page">
                <div class="box-body">
                    
        <h2>Questionnaire for Applicant</h2>
<div class="question-box"> 
            <label>1. Please give a candid description of yourself as a person:</label>
            <input type="text" name="description" rows="4" value="<?= $applicant['questionnaire']['description'] ?? '' ?>" class="editable-field readonly" readonly><br><br><br><br>

            <label>2. What is your job objective and career plans for the future?</label>
            <input type="text" name="career_plans" rows="4" value="<?= $applicant['questionnaire']['career_plans'] ?? '' ?>" class="editable-field readonly" readonly><br><br><br><br>

            <label>3. Why do you want to join the teaching or office staff of EXACT Colleges of Asia?
            <input type="text" name="reason_for_joining" rows="4" value="<?= $applicant['questionnaire']['reason_for_joining'] ?? '' ?>" class="editable-field readonly" readonly><br><br><br><br>

            <label>4. Why do you think EXACT Inc. should hire you?</label>
            <input type="text" name="why_hire" rows="4" value="<?= $applicant['questionnaire']['why_hire'] ?? '' ?>" class="editable-field readonly" readonly><br><br><br><br>

            <label>5. In case you are hired, what do you expect in return from EXACT Colleges of Asia?</label>
            <input type="text" name="expectations"  value="<?= $applicant['questionnaire']['expectations'] ?? '' ?>" class="editable-field readonly" readonly><br><br>
            </div>
            </div>
            <h3>Upload Required Documents</h3>
<div class="file-upload-container">

<!-- Resume -->
<div class="file-box">
    <label class="custom-file-button">
        <input type="file" id="resumeInput" name="resume_applicant[]" multiple hidden onchange="updateFileList(this)">
        Select Files
    </label>
    <p>Resume (Applicant)</p>
    <div class="file-list" id="resumeList">
        <?php
        $docs = $applicant['documents']['resume_applicant'] ?? [];

        if (!empty($docs)) {
            try {
                require_once '../vendor/autoload.php'; // Load MongoDB if not already
                $client = new MongoDB\Client;
                $database = $client->hrims_db; // ← CHANGE this to your DB
                $filesCollection = $database->selectCollection('fs.files');

                foreach ($docs as $fileId) {
                    $file = $filesCollection->findOne([
                        '_id' => new MongoDB\BSON\ObjectId($fileId)
                    ]);

                    if ($file) {
                        $fileName = $file->filename ?? 'Unnamed File';
                        echo '<div style="margin-bottom: 8px; display: flex; align-items: center; gap: 10px;">';
                        echo '<span>' . htmlspecialchars($fileName) . '</span>';
                        echo '<a href="view_file.php?id=' . $fileId . '" target="_blank">';
                        echo '<button type="button">View</button>';
                        echo '</a>';
                        echo '</div>';
                    } else {
                        echo '<p>File not found.</p>';
                    }
                }
            } catch (Exception $e) {
                echo '<p style="color: red;">⚠ Error loading files: ' . htmlspecialchars($e->getMessage()) . '</p>';
            }
        } else {
            echo '<p>No files selected</p>';
        }
        ?>
    </div>
</div>


    <!-- Training Certificates -->
    <div class="file-box">
        <label class="custom-file-button">
            <input type="file" id="trainingInput" name="training_certificates[]" multiple hidden onchange="updateFileList(this)">
            Select Files
        </label>
        <p>Training Certificates</p>
        <div class="file-list" id="trainingList">
        <?php
        $docs = $applicant['documents']['training_certificates'] ?? [];

        if (!empty($docs)) {
            try {
                require_once '../vendor/autoload.php'; // Load MongoDB if not already
                $client = new MongoDB\Client;
                $database = $client->hrims_db; // ← CHANGE this to your DB
                $filesCollection = $database->selectCollection('fs.files');

                foreach ($docs as $fileId) {
                    $file = $filesCollection->findOne([
                        '_id' => new MongoDB\BSON\ObjectId($fileId)
                    ]);

                    if ($file) {
                        $fileName = $file->filename ?? 'Unnamed File';
                        echo '<div style="margin-bottom: 8px; display: flex; align-items: center; gap: 10px;">';
                        echo '<span>' . htmlspecialchars($fileName) . '</span>';
                        echo '<a href="view_file.php?id=' . $fileId . '" target="_blank">';
                        echo '<button type="button">View</button>';
                        echo '</a>';
                        echo '</div>';
                    } else {
                        echo '<p>File not found.</p>';
                    }
                }
            } catch (Exception $e) {
                echo '<p style="color: red;">⚠ Error loading files: ' . htmlspecialchars($e->getMessage()) . '</p>';
            }
        } else {
            echo '<p>No files selected</p>';
        }
        ?>
        </div>
    </div>

    <!-- Diploma -->
    <div class="file-box">
        <label class="custom-file-button">
            <input type="file" id="diplomaInput" name="diploma[]" multiple hidden onchange="updateFileList(this)">
            Select Files
        </label>
        <p>Diploma</p>
        <div class="file-list" id="diplomaList">
        <?php
        $docs = $applicant['documents']['diploma'] ?? [];

        if (!empty($docs)) {
            try {
                require_once '../vendor/autoload.php'; // Load MongoDB if not already
                $client = new MongoDB\Client;
                $database = $client->hrims_db; // ← CHANGE this to your DB
                $filesCollection = $database->selectCollection('fs.files');

                foreach ($docs as $fileId) {
                    $file = $filesCollection->findOne([
                        '_id' => new MongoDB\BSON\ObjectId($fileId)
                    ]);

                    if ($file) {
                        $fileName = $file->filename ?? 'Unnamed File';
                        echo '<div style="margin-bottom: 8px; display: flex; align-items: center; gap: 10px;">';
                        echo '<span>' . htmlspecialchars($fileName) . '</span>';
                        echo '<a href="view_file.php?id=' . $fileId . '" target="_blank">';
                        echo '<button type="button">View</button>';
                        echo '</a>';
                        echo '</div>';
                    } else {
                        echo '<p>File not found.</p>';
                    }
                }
            } catch (Exception $e) {
                echo '<p style="color: red;">⚠ Error loading files: ' . htmlspecialchars($e->getMessage()) . '</p>';
            }
        } else {
            echo '<p>No files selected</p>';
        }
        ?>
        </div>
    </div>

    <!-- Contracts -->
    <div class="file-box">
        <label class="custom-file-button">
            <input type="file" id="contractsInput" name="contracts[]" multiple hidden onchange="updateFileList(this)">
            Select Files
        </label>
        <p>Contracts</p>
        <div class="file-list" id="contractsList">
        <?php
        $docs = $applicant['documents']['contracts'] ?? [];

        if (!empty($docs)) {
            try {
                require_once '../vendor/autoload.php'; // Load MongoDB if not already
                $client = new MongoDB\Client;
                $database = $client->hrims_db; // ← CHANGE this to your DB
                $filesCollection = $database->selectCollection('fs.files');

                foreach ($docs as $fileId) {
                    $file = $filesCollection->findOne([
                        '_id' => new MongoDB\BSON\ObjectId($fileId)
                    ]);

                    if ($file) {
                        $fileName = $file->filename ?? 'Unnamed File';
                        echo '<div style="margin-bottom: 8px; display: flex; align-items: center; gap: 10px;">';
                        echo '<span>' . htmlspecialchars($fileName) . '</span>';
                        echo '<a href="view_file.php?id=' . $fileId . '" target="_blank">';
                        echo '<button type="button">View</button>';
                        echo '</a>';
                        echo '</div>';
                    } else {
                        echo '<p>File not found.</p>';
                    }
                }
            } catch (Exception $e) {
                echo '<p style="color: red;">⚠ Error loading files: ' . htmlspecialchars($e->getMessage()) . '</p>';
            }
        } else {
            echo '<p>No files selected</p>';
        }
        ?>
        </div>
    </div>

    <!-- Transcript of Records -->
    <div class="file-box">
        <label class="custom-file-button">
            <input type="file" id="torInput" name="transcript_of_records[]" multiple hidden onchange="updateFileList(this)">
            Select Files
        </label>
        <p>Transcript of Records (Bachelor, Masteral, and PhD)</p>
        <div class="file-list" id="torList">
        <?php
        $docs = $applicant['documents']['transcript_of_records'] ?? [];

        if (!empty($docs)) {
            try {
                require_once '../vendor/autoload.php'; // Load MongoDB if not already
                $client = new MongoDB\Client;
                $database = $client->hrims_db; // ← CHANGE this to your DB
                $filesCollection = $database->selectCollection('fs.files');

                foreach ($docs as $fileId) {
                    $file = $filesCollection->findOne([
                        '_id' => new MongoDB\BSON\ObjectId($fileId)
                    ]);

                    if ($file) {
                        $fileName = $file->filename ?? 'Unnamed File';
                        echo '<div style="margin-bottom: 8px; display: flex; align-items: center; gap: 10px;">';
                        echo '<span>' . htmlspecialchars($fileName) . '</span>';
                        echo '<a href="view_file.php?id=' . $fileId . '" target="_blank">';
                        echo '<button type="button">View</button>';
                        echo '</a>';
                        echo '</div>';
                    } else {
                        echo '<p>File not found.</p>';
                    }
                }
            } catch (Exception $e) {
                echo '<p style="color: red;">⚠ Error loading files: ' . htmlspecialchars($e->getMessage()) . '</p>';
            }
        } else {
            echo '<p>No files selected</p>';
        }
        ?>
        </div>
    </div>

</div>

<!-- Navigation Buttons -->
<div class="navigation-box">
    <div class="navigation">
        <button onclick="showPage('page1')" type="button">Previous</button>
        <button type="submit">Submit</button>
    </div>
</div>

</form>

    </div>
    
</div>
</body>
</html>
<script>
        function showPage(pageId) {
            document.querySelectorAll('.page').forEach(page => {
                page.classList.remove('active');
            });
            document.getElementById(pageId).classList.add('active');
        }
        function updateFileName(input) {
    let fileNameContainer = input.closest('.upload-box').querySelector('.file-name');
    let removeButton = input.closest('.upload-box').querySelector('.remove-file');

    let fileNames = [];
    for (let i = 0; i < input.files.length; i++) {
        fileNames.push(input.files[i].name);
    }

    if (fileNames.length > 0) {
        fileNameContainer.textContent = fileNames.join(", ");
        removeButton.style.display = 'inline-block';
    } else {
        fileNameContainer.textContent = "";
        removeButton.style.display = 'none';
    }
}

function toggleEdit(formId, button) {
  const form = document.getElementById(formId);
  const fields = form.querySelectorAll('.editable-field');

  if (fields.length === 0) {
    console.warn("No editable fields found in form:", formId);
    return;
  }

  const isReadOnly = fields[0].hasAttribute("readonly");

  fields.forEach(field => {
    if (isReadOnly) {
      field.removeAttribute("readonly");
      field.classList.remove("readonly");
    } else {
      field.setAttribute("readonly", true);
      field.classList.add("readonly");
    }
  });

  button.textContent = isReadOnly ? 'Save' : 'Edit';
}

    </script>