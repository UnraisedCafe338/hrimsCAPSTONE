<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $prompt = $_POST["prompt"] ?? '';
    $escaped_prompt = escapeshellarg($prompt);

    $resumeFile = $_SESSION["latest_resume"] ?? '';
    $resumeFileName = basename($resumeFile);
    $escaped_resume = escapeshellarg($resumeFileName);

    $python = "C:\\Users\\LENOVO\\AppData\\Local\\Programs\\Python\\Python312\\python.exe";
    $script = escapeshellarg("ai_script.py");

    // If document exists, send it as second arg, else skip it
    $command = empty($resumeFile) ? 
        "$python $script $escaped_prompt" : 
        "$python $script $escaped_prompt $escaped_resume";
        
    $output = [];
    $return_var = 0;
    exec($command . " 2>&1", $output, $return_var);

    if ($return_var !== 0 || empty($output)) {
        echo "AI failed to respond. Error details: " . implode("\n", $output);
    } else {
        echo implode("\n", $output);
    }
}
?>
