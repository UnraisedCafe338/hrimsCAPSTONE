<?php

session_start();
require '../connection.php';
require '../vendor/autoload.php';

use MongoDB\BSON\ObjectId;
use Sonata\GoogleAuthenticator\GoogleAuthenticator;
use Sonata\GoogleAuthenticator\GoogleQrUrl;

$collection = $database->users;

// Fetch the admin user (you can modify the filter to get a specific admin if needed)
$admin = $collection->findOne([]); 

if (!$admin) {
    die("Admin user not found.");
}

$message = "";

// Handle Gmail (email) update
if (isset($_POST['update_email'])) {
    $new_email = trim($_POST['new_email']);

    if (!empty($new_email)) {
        $existingEmail = $collection->findOne(['email' => $new_email]);
        if ($existingEmail) {
            $message = "Email already taken.";
        } else {
            $collection->updateOne(
                ['_id' => $admin['_id']],
                ['$set' => ['email' => $new_email]]
            );
            $message = "Email updated successfully!";
        }
    } else {
        $message = "Email cannot be empty.";
    }
}

// Handle OTP secret update (regenerate new OTP)
if (isset($_POST['update_otp'])) {
    $g = new GoogleAuthenticator();
    $new_secret = $g->generateSecret();

    // Update the secret in the database
    $collection->updateOne(
        ['_id' => $admin['_id']],
        ['$set' => ['otp_secret' => $new_secret]]
    );
    
    // Store the new secret in session so it can be used for the QR code immediately
    $_SESSION['new_otp_secret'] = $new_secret;
    
    $message = "OTP secret regenerated successfully! Please scan the new QR code.";
}

?>
<?php include 'sidebar.php'; ?>
<div class="content">
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Settings</title>
</head>
<body>
    <h2>Admin Settings</h2>

    <p><strong>Gmail (Current):</strong> <?php echo htmlspecialchars($admin['email'] ?? 'No email set'); ?></p>

    <form method="POST">
        <input type="email" name="new_email" placeholder="New Gmail Address" required>
        <button type="submit" name="update_email">Edit Gmail</button>
    </form>

    <h3>Update OTP</h3>
    <form method="POST">
        <button type="submit" name="update_otp">Regenerate New OTP Secret</button>
    </form>

    <br>
    <?php 
        if (isset($_SESSION['new_otp_secret'])) {
            $otp_secret = $_SESSION['new_otp_secret']; // Get the new OTP secret from session
        } else {
            $otp_secret = $admin['otp_secret']; // Use the existing secret if not regenerated
        }

        if (isset($otp_secret)): 
    ?>
        <h3>Scan this QR Code (Google Authenticator)</h3>
        <?php
            $qrUrl = GoogleQrUrl::generate(
                $admin['email'] ?? 'admin@hrims.local', // Email will show on Google Authenticator
                $otp_secret,  // OTP secret (either old or new)
                'HRIMS' // Your system name
            );
            echo "<img src=\"$qrUrl\">";
        ?>
    <?php endif; ?>

    <p style="color:green;"><?php echo $message; ?></p>

    <form action="register.php" method="GET">
        <button type="submit" class="register-button">Register New Account</button>
    </form>

</body>
</html>
</div>
