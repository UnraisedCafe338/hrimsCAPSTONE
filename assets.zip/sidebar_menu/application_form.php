<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employment Application Form</title>
    <link rel="stylesheet" href="../css/application_form.css?v=<?=filemtime('../css/application_form.css')?>">

    <style>
.validation-message small {
    position: relative;
    background:rgb(255, 100, 100);
    padding: 12px 16px;
    border-radius: 12px;
    max-width: 370px;
    margin-top: 10px;
    left: 28rem;
    font-family: sans-serif;
    box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
}
.validation-message small {
    position: absolute;
    top: 100%; /* below the parent */
    left: 0; /* start at parent's left edge */
    margin-top: 8px;
}

.validation-message small:before {
content: "";
  position: absolute;
  top: -10px;
  left: 10px;
  width: 0;
  height: 0;
  border-left: 10px solid transparent;
  border-right: 10px solid transparent;
  border-bottom: 10px solid rgb(255, 100, 100);
}

</style>
</head>
<?php include 'sidebar.php'; ?>

<body> 
<div id="privacyModal" class="modal">
            <div class="modal-content">
            <button class="x" onclick="exitForm()">X</button>

                <h2>Data Privacy Notice</h2>
                <p>
                By proceeding with this application form, I acknowledge that the personnel information I providing will be collected and processed by the HR Department in accordance with the Data Privacy Act of 2012.
                </p>
                <button class="agree" onclick="closePrivacyModal()">I Agree</button>
            </div>
            </div>

            <div id="confirmModal" class="modal-overlay" style="display: none;">
  <div class="modal-box2">
    <h3>Are you sure you want to submit?</h3>
    <div class="modal-buttons">
      <button class="yes-btn" id="yesButton" onclick="submitForm()">Yes</button>
      <button class="no-btn" onclick="closeModal()">No</button>
    </div>
  </div>
</div>
    <div class="header">Employment Application Form</div><br><br><br><br>
<div class="content">

  
    <div class="box-header">
        <form action="../handlers/process_application.php" method="POST" id="empform" enctype="multipart/form-data">   
            <a href="applicants.php" class="button"> Back </a>
       
    </div>
    <div class="box-body">
        <!-- filepath: vsls:/sidebar_menu/application_form.php -->
    <div id="page1" class="page active">
        <form action="" method="post">
            <div class="form-container_left">
                <table class="form-table">
                    <thead>
                        <tr>
                            <th colspan="6"><h3>Personal Information</h3></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td colspan="1"><label>Name:</label></td>
                            <td colspan="5">
                                <div style="width: 100%; display: flex; gap: 2px;">
                                <input type="text" placeholder="Last Name">
                                <input type="text" placeholder="First Name">
                                <input type="text" placeholder="Middle Name">
                                </div>
                            </td>
                        </tr>
                        <tr class="applicant_address">
                            <td rowspan="2"><label>Personal Address:</label></td>

                            <!-- First row: Region, Province, Municipality (total colspan=5) -->
                            <td colspan="5">
                                <div style="display: flex; gap: 5px; width: 100%;">
                                    <select id="personal_region" onchange="loadProvinces('personal')" required>
                                        <option value="">Select Region</option>
                                    </select>
                                    <select id="personal_province" onchange="loadMunicipalities('personal')" disabled required>
                                        <option value="">Select Province</option>
                                    </select>
                                    <select id="personal_municipality" onchange="loadBarangays('personal')" disabled required>
                                        <option value="">Select Municipality</option>
                                    </select>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <!-- Second row: Barangay (colspan=2) and Street (colspan=3) -->
                            <td colspan="2">
                                <select id="personal_barangay" disabled required style="width: 100%;">
                                    <option value="">Select Barangay</option>
                                </select>
                            </td>
                            <td colspan="3">
                                <input type="text" placeholder="Street" required style="width: 100%;">
                            </td>
                        </tr>

                        <tr style="width: 100%">
                            <td colspan="1"><label>Email:</label></td>
                            <td colspan="2"><input type="email"></td>
                            <td colspan="1"><label>Contact No.:</label></td>
                            <td colspan="2"><input type="text"></td>
                        </tr>
                        <tr>
                            <td colspan="1"><label>Birth Date:</label></td>
                            <td colspan="2"><input type="date" id="birthdate"></td>
                            <td colspan="1"><label>Birth Place:</label></td>
                            <td colspan="2"><input type="text"></td>
                        </tr>
                        <tr>
                            <td colspan="1"><label>Age:</label></td>
                            <td colspan="2"><input type="text" id="age" readonly></td> <!-- make it readonly -->
                            <td colspan="1"><label>Gender:</label></td>
                            <td colspan="2"><select id="gender" name="gender">
                            <option value="">-- Select Gender --</option>
                            <option value="male">Male</option>
                            <option value="female">Female</option>
                            <option value="nonbinary">Non-binary</option>
                            <option value="prefer_not_to_say">Prefer not to say</option>
                            <option value="other">Other</option>
                            </select></td>
                        </tr>
                        <tr style="width: 100%">
                            <td colspan="1"><label>Height:</label></td>
                            <td colspan="2"><input type="email"></td>
                            <td colspan="1"><label>Weight:</label></td>
                            <td colspan="2"><input type="text"></td>
                        </tr>
                        <tr style="width: 100%;">                       
                         <div style="">
                            <td style="width: 13;"><label>Citizen:</label></td>
                            <td style="width: 20%;"><input type="email"></td>
                            <td style="width: 13%;"><label>Civil Status:</label></td>
                            <td style="width: 20%;" ><input type="text"></td>
                            <td style="width: 13%;"><label>Religion:</label></td>
                            <td style="width: 20%;"><input type="email"></td>
                         </div>
                        </tr>
                        <tr style="width: 100%">
                            <td colspan="3" style="width: 50% ;"><label>Do you have any physical defects?</label></td>
                            <td colspan="3" style="width: 50%;"><input type="text"></td>
                        </tr>
                        </tr>
                    </tbody>
                </table>
                <table class="form-table">
                    <thead>
                        <tr>
                            <th colspan="4"><h3>Family Background: </h3></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td style="width: 15%;"><label>Father's Name:</label></td>
                            <td style="width: 35%"><input type="text"></td>
                            <td><label>Occupation:</label></td>
                            <td><input type="text"></td>
                        </tr>
                        <tr>
                            <td><label>Mother's Name:</label></td>
                            <td><input type="text"></td>
                            <td><label>Occupation:</label></td>
                            <td><input type="text"></td>
                        </tr>
                        <tr>
                        <td colspan="1"><label>Parent's Address:</label></td>
<td colspan="5">
  <div style="width: 100%; display: flex; gap: 2px;">
    <select id="parent_region" onchange="loadProvinces('parent')" required>
      <option value="">Select Region</option>
    </select>
    <select id="parent_province" onchange="loadMunicipalities('parent')" disabled required>
      <option value="">Select Province</option>
    </select>
    <select id="parent_municipality" onchange="loadBarangays('parent')" disabled required>
      <option value="">Select Municipality</option>
    </select>
    <select id="parent_barangay" disabled required>
      <option value="">Select Barangay</option>
    </select>
    <input type="text" placeholder="Street" required>
  </div>
</td>

                        </tr>
                        <tr>
                            <td><label>Spouse Name:</label></td>
                            <td><input type="text"></td>
                            <td><label>Occupation:</label></td>
                            <td><input type="text"></td>
                        </tr>
                    </tbody>
                </table>
                <table class="form-table">  
                        <thead>
                            <tr>
                                <th colspan="6"><h3>Educational Background</h3></th>
                            </tr>
                            <tr>
                                <th><h4>School and Address:</h4></th>
                                <th><h4 >Degree/Honor Received:</h4></th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>   
                                <td><input type="text" placeholder="Elementary"></td>
                                <td><input type="text"></td>
                            </tr>
                            <tr>
                                
                                <td><input type="text" placeholder="High School"></td>
                                <td><input type="text"></td>
                            </tr>
                            <tr>
                                <td><input type="text" placeholder="College"></td>
                                <td><input type="text"></td>
                            </tr>
                            <tr>
                                
                                <td><input type="text" placeholder="Tertiary"></td>
                                <td><input type="text"></td>
                            </tr>
                        </tbody>
                </table>
            </div>
            <div class="form_container rignt">
                <table class="form-table">
                    <thead>
                        <tr>
                            <th colspan="6"><h3>Employment Record</h3></th>
                        </tr>
                        <tr>
                            <td><h4><label>Company & Address</label></h4></td>
                            <td><h4><label>Position</label></h4></td>
                            <td><h4><label>Reason for Leaving</label></h4></td>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><label>Company & Address</label></td>
                            <td><label>Position</label></td>
                            <td><label>Reason for Leaving</label></td>
                        </tr>
                        <tr>
                            <td><input type="text"></td>
                            <td><input type="text"></td>
                            <td><input type="text"></td>
                        </tr>
                        <tr>
                            <td><input type="text"></td>
                            <td><input type="text"></td>
                            <td><input type="text"></td>
                        </tr>
                        <tr>
                            <td><input type="text"></td>
                            <td><input type="text"></td>
                            <td><input type="text"></td>
                        </tr>
                        
                    </tbody>
                </table>

                <!-- Emergency Contact Table -->
                <table class="form-table">
                    <thead>
                        <tr>
                            <th colspan="2"><h3>Emergency Contact</h3></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><label>Person to Notify</label></td>
                            <td><input type="text"></td>
                        </tr>
                        <tr>
                            <td><label>Relationship</label></td>
                            <td><input type="text"></td>
                        </tr>
                        <tr>
                            <td><label>Address</label></td>
                            <td><input type="text"></td>
                        </tr>
                        <tr>
                            <td><label>Contact Number</label></td>
                            <td><input type="text"></td>
                        </tr>
                    </tbody>
                </table>

                <!-- Character Reference Table -->
                <table class="form-table">
                    <thead>
                        <tr>
                            <th colspan="2"><h3>Character Reference</h3></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><label>Name</label></td>
                            <td><input type="text"></td>
                        </tr>
                        <tr>
                            <td><label>Company</label></td>
                            <td><input type="text"></td>
                        </tr>
                        <tr>
                            <td><label>Position</label></td>
                            <td><input type="text"></td>
                        </tr>
                        <tr>
                            <td><label>Contact No.</label></td>
                            <td><input type="text"></td>
                        </tr>
                    </tbody>
                </table>
                <table class="form-table">
                    <thead>
                        <tr>
                            <th colspan="6"><h3>Other Information</h3></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><label>How did you learn about this position?</label></td>
                            <td class="td"><input type="text"></td>
                        </tr>
                        <tr>
                            <td><label>Are you willing to work overtime?</label></td>
                            <td class="td"><input type="text"></td>
                        </tr>
                        <tr>
                            <td><label>Are you willing to travel?</label></td>
                            <td ><input type="text"></td>
                        </tr>
                    </tbody>
                </table>
                <table class="form-table">
                    <thead>
                            <th colspan="6"><h3>Skills</h3></th>
                    </thead>
                    <tbody>
                        <tr>
                            <td><textarea style="height: 100px; width: 100%; resize: vertical; max-height:300px;" name="skills" id="skills"></textarea></td>
                        </tr>
                            
                    </tbody>
                </table>
            </div>
        </form>
        <div class="navigation-box">
            <div class="navigation">
                <button onclick="showPage('page2')" type="button">Next</button>
            </div>
        </div>
    </div>
                
            
                <div id="page2" class="page">
                    <div class="question-box">
                        <h2>Questionnaire for Applicant (1/5)</h2>
                        <label class="label">1. Please give a candid description of yourself as a person:</label>
                        <textarea type="text" name="description" rows="4" class="question-box"></textarea><br><br>
                    </div>
                    <div class="navigation-box">
                        <div class="navigation">
                            <button onclick="showPage('page1')" type="button">Previous</button>
                            <button onclick="showPage('page3')" type="button">Next</button>
                        </div>
                    </div>
                </div>
                    <div id="page3" class="page">
                        <div class="question-box">
                        <h2>Questionnaire for Applicant (2/5)</h2>
                        <label class="label">2. What is your job objective and career plans for the future?</label>
                        <textarea type="text" name="career_plans" rows="4" class="question-box"></textarea><br><br>
                        <div class="navigation-box">
                            <div class="navigation">
                            <button onclick="showPage('page2')" type="button">Previous</button>
                            <button onclick="showPage('page4')" type="button">Next</button>
                            </div>
                        </div>
                        </div>
                    </div>    
                    <div id="page4" class="page">
                        <div class="question-box">
                        <h2>Questionnaire for Applicant (3/5)</h2>
                            <label  class="label">3. Why do you want to join the teaching or office staff of EXACT Colleges of Asia?</input></label>
                            <textarea type="text" name="reason_for_joining" rows="4" class="question-box"></textarea><br><br>
                        </div>
                        <div class="navigation-box">
                            <div class="navigation">
                            <button onclick="showPage('page3')" type="button">Previous</button>
                            <button onclick="showPage('page5')" type="button">Next</button>
                            </div>
                        </div>
                    </div>
                    <div id="page5" class="page">
                        <div class="question-box">
                        <h2>Questionnaire for Applicant (4/5)</h2>
                            <label class="label">4. Why do you think EXACT Inc. should hire you?</label>
                            <textarea type="text" name="why_hire" rows="4" class="question-box"></textarea><br><br>
                        </div>
                        <div class="navigation-box">
                            <div class="navigation">
                                <button onclick="showPage('page4')" type="button">Previous</button>
                                <button onclick="showPage('page6')" type="button">Next</button>
                            </div>
                        </div>
                    </div>    
                    <div id="page6" class="page">
                        <div class="question-box">
                            <h2>Questionnaire for Applicant (5/5)</h2>
                            <label class="label">5. In case you are hired, what do you expect in return from EXACT Colleges of Asia?</label>
                            <textarea type="text" name="expectations" rows="4" class="question-box"></textarea><br><br>
                        </div>
                        <div class="navigation-box">
                            <div class="navigation">
                                <button onclick="showPage('page5')" type="button">Previous</button>
                                <button onclick="showPage('page7')" type="button">Next</button>
                            </div>
                        </div>
                    </div>
                    <div id="page7" class="page">
                        <h3>Upload Required Documents</h3>
                        <div class="file-upload-container">
                            <div class="file-box">
                                <label class="custom-file-button">
                                <input type="file" id="resumeInput" name="resume_applicant[]" multiple hidden onchange="updateFileList(this)">
                                    Select Files
                                </label>
                            <p>Resume (Applicant)</p>
                                <div class="file-list" id="resumeList">
                                    <p>No files selected</p>
                                </div>
                            </div>

                            <div class="file-box">
                                <label class="custom-file-button">
                                <input type="file" id="trainingInput" name="training_certificates[]" multiple hidden onchange="updateFileList(this)">
                                    Select Files
                                </label>
                            <p>Training Certificates</p>
                                <div class="file-list" id="trainingList">
                                    <p>No files selected</p>
                                </div>
                            </div>

                            <div class="file-box">
                                <label class="custom-file-button">
                                <input type="file" id="diplomaInput" name="diploma[]" multiple hidden onchange="updateFileList(this)">
                                    Select Files
                                </label>
                            <p>Diploma</p>
                                <div class="file-list" id="diplomaList">
                                    <p>No files selected</p>
                                </div>
                            </div>

                        <div class="file-box">
                            <label class="custom-file-button">
                                <input type="file" id="contractsInput" name="contracts[]" multiple hidden onchange="updateFileList(this)">
                                Select Files
                            </label>
                            <p>Contracts</p>
                            <div class="file-list" id="contractsList">
                            <p>No files selected</p>
                            </div>
                        </div>

                        
                        <div class="file-box">
                            <label class="custom-file-button">
                            <input type="file" id="torInput" name="transcript_of_records[]" multiple hidden onchange="updateFileList(this)">
                                Select Files
                            </label>
                            <p>Transcript of Records (Bachelor, Masteral, and PhD)</p>
                            <div class="file-list" id="torList">
                            <p>No files selected</p>
                            </div>
                        </div>
                    </div>

                    <div class="navigation">
    <button onclick="showPage('page6')" type="button">Previous</button>
    <button type="button" onclick="handleSubmitClick()" id="submitButton">Submit</button>  
</div>

<div class="confirmation">
    <label>
        <input type="checkbox" id="certifyCheckbox" name="certify">
        I hereby certify that the above information is true and complete to the best of my knowledge.
    </label>

</div>
<div id="checkboxMessage" class="validation-message" style="display: none;">
        <small>Please check this box to confirm before submitting.</small>
    </div>
    <script> 
            function handleSubmitClick() {
                const checkbox = document.getElementById('certifyCheckbox');
                const message = document.getElementById('checkboxMessage');

                if (checkbox.checked) {
                    message.style.display = 'none';
                    showModal(); // Call your existing function to open the modal
                } else {
                    message.style.display = 'block';
                }
            }
                // function previewPhoto(event) {
                //     const reader = new FileReader();
                //     reader.onload = function () {
                //     const preview = document.getElementById("photoPreview");
                //     preview.src = reader.result;
                //     preview.style.display = "block";
                //     };
                //     reader.readAsDataURL(event.target.files[0]);
                // }
            function previewPhoto(event) {
            const reader = new FileReader();
            reader.onload = function () {
                const preview = document.getElementById("photoPreview");
                preview.src = reader.result;
                preview.style.display = "block";
            };
            reader.readAsDataURL(event.target.files[0]);
            }

            function showPage(pageId) {
                document.querySelectorAll('.page').forEach(page => {
                    page.classList.remove('active');
                });
                document.getElementById(pageId).classList.add('active');
            }
            // function updateFileName(input) {
            //     let fileNameContainer = input.closest('.upload-box').querySelector('.file-name');
            //     let removeButton = input.closest('.upload-box').querySelector('.remove-file');

            //     let fileNames = [];
            //     for (let i = 0; i < input.files.length; i++) {
            //         fileNames.push(input.files[i].name);
            //     }

            //     if (fileNames.length > 0) {
            //         fileNameContainer.textContent = fileNames.join(", ");
            //         removeButton.style.display = 'inline-block';
            //     } else {
            //         fileNameContainer.textContent = "";
            //         removeButton.style.display = 'none';
            //     }
            // }
            // const fileInput = document.getElementById("fileInput2");
            //     const uploadBox = document.getElementById("uploadBox");
            //     const uploadText = document.getElementById("uploadText2");

            // fileInput.addEventListener("change", function () {
            //     const file = this.files[0];
            //     if (file) {
            //         const reader = new FileReader();
            //         reader.onload = function (e) {
            //             uploadBox.style.backgroundImage = `url(${e.target.result})`;
            //             uploadText.style.display = "none"; // Hide text after upload
            //         };
            //         reader.readAsDataURL(file);
            //     }
            // });


            const fileStore = new Map();

            function updateFileList(input) {
            const fileBox = input.closest('.file-box');
            const fileListContainer = fileBox.querySelector('.file-list');
            const inputName = input.name;

            let storedFiles = fileStore.get(inputName) || [];
            const newFiles = Array.from(input.files);

            storedFiles = storedFiles.concat(newFiles);

            // Remove duplicates
            storedFiles = storedFiles.filter((file, index, self) =>
                index === self.findIndex(f => f.name === file.name && f.size === file.size)
            );

            fileStore.set(inputName, storedFiles);

            const newDataTransfer = new DataTransfer();
            storedFiles.forEach(file => newDataTransfer.items.add(file));
            input.files = newDataTransfer.files;

            // Show file names
            fileListContainer.innerHTML = "";
            if (storedFiles.length > 0) {
                storedFiles.forEach((file, i) => {
                const fileItem = document.createElement("div");
                fileItem.classList.add("file-item");
                fileItem.innerHTML = `
                    <span>${file.name} (${(file.size / 1024).toFixed(1)} KB)</span>
                    <button type="button" class="remove-file" onclick="removeFile(this, '${inputName}', ${i})">❌</button>
                `;
                fileListContainer.appendChild(fileItem);
                });
            } else {
                fileListContainer.innerHTML = "<p>No files selected</p>";
            }
            }

            function removeFile(button, inputName, index) {
            const fileBox = button.closest('.file-box');
            const input = fileBox.querySelector('input[type="file"]');
            let storedFiles = fileStore.get(inputName) || [];

            storedFiles.splice(index, 1);
            fileStore.set(inputName, storedFiles);

            const dataTransfer = new DataTransfer();
            storedFiles.forEach(file => dataTransfer.items.add(file));
            input.files = dataTransfer.files;

            updateFileList(input);
            }

            function showModal() {
                document.getElementById('confirmModal').style.display = 'flex';
            }
            function closeModal() {
                document.getElementById('confirmModal').style.display = 'none';
            }
            function submitForm() {
                document.getElementById('empform').submit();
            }

            function closePrivacyModal() {
            document.getElementById("privacyModal").style.display = "none";
            }

            function exitForm() {
                window.location.href = 'applicants.php';

            }
            document.getElementById('birthdate').addEventListener('change', function() {
                const birthdate = new Date(this.value);
                const today = new Date();

                let age = today.getFullYear() - birthdate.getFullYear();
                const m = today.getMonth() - birthdate.getMonth();

                // Adjust if birth month/day hasn't occurred yet this year
                if (m < 0 || (m === 0 && today.getDate() < birthdate.getDate())) {
                    age--;
                }

                document.getElementById('age').value = age;
            });
            window.onload = function () {
  loadRegions('personal');
  loadRegions('parent');
};

function loadRegions(type) {
  fetch('../handlers/get_regions.php')
    .then(response => response.json())
    .then(data => {
      const regionDropdown = document.getElementById(`${type}_region`);
      data.forEach(region => {
        regionDropdown.innerHTML += `<option value="${region.id}">${region.name}</option>`;
      });
    });
}

function loadProvinces(type) {
  const regionId = document.getElementById(`${type}_region`).value;
  const provinceDropdown = document.getElementById(`${type}_province`);
  const municipalityDropdown = document.getElementById(`${type}_municipality`);
  const barangayDropdown = document.getElementById(`${type}_barangay`);

  provinceDropdown.innerHTML = `<option value="">Select Province</option>`;
  municipalityDropdown.innerHTML = `<option value="">Select Municipality</option>`;
  barangayDropdown.innerHTML = `<option value="">Select Barangay</option>`;
  
  municipalityDropdown.disabled = true;
  barangayDropdown.disabled = true;

  if (regionId) {
    fetch(`../handlers/get_provinces.php?region_id=${regionId}`)
      .then(res => res.json())
      .then(data => {
        data.forEach(province => {
          provinceDropdown.innerHTML += `<option value="${province.id}">${province.name}</option>`;
        });
        provinceDropdown.disabled = false;
      });
  }
}

function loadMunicipalities(type) {
  const provinceId = document.getElementById(`${type}_province`).value;
  const municipalityDropdown = document.getElementById(`${type}_municipality`);
  const barangayDropdown = document.getElementById(`${type}_barangay`);

  municipalityDropdown.innerHTML = `<option value="">Select Municipality</option>`;
  barangayDropdown.innerHTML = `<option value="">Select Barangay</option>`;
  
  barangayDropdown.disabled = true;

  if (provinceId) {
    fetch(`../handlers/get_municipalities.php?province_id=${provinceId}`)
      .then(res => res.json())
      .then(data => {
        data.forEach(municipality => {
          municipalityDropdown.innerHTML += `<option value="${municipality.id}">${municipality.name}</option>`;
        });
        municipalityDropdown.disabled = false;
      });
  }
}

function loadBarangays(type) {
  const municipalityId = document.getElementById(`${type}_municipality`).value;
  const barangayDropdown = document.getElementById(`${type}_barangay`);

  barangayDropdown.innerHTML = `<option value="">Select Barangay</option>`;

  if (municipalityId) {
    fetch(`../handlers/get_barangays.php?municipality_id=${municipalityId}`)
      .then(res => res.json())
      .then(data => {
        data.forEach(barangay => {
          barangayDropdown.innerHTML += `<option value="${barangay.id}">${barangay.name}</option>`;
        });
        barangayDropdown.disabled = false;
      });
  }
}

    </script>
    </body>
</html>