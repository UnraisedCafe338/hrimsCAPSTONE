import sys
import os
from docx import Document
from llama_cpp import Llama
import fitz  # PyMuPDF

# Initialize Mistral model
llm = Llama(
    model_path="C:/Users/LENOVO/Downloads/mistral-7b-instruct-v0.2.Q4_K_M.gguf",
    n_ctx=2048,
    n_threads=4
)

UPLOAD_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "../uploads"))

def extract_text(file_name):
    ext = os.path.splitext(file_name)[1].lower()
    path = os.path.join(UPLOAD_DIR, file_name)

    if not os.path.exists(path):
        return ""

    try:
        if ext == '.docx':
            return read_docx(path)
        elif ext == '.pdf':
            return read_pdf(path)
        elif ext == '.txt':
            return read_txt(path)
        else:
            return ""
    except Exception:
        return ""

def read_docx(path):
    doc = Document(path)
    return "\n".join([p.text for p in doc.paragraphs if p.text.strip()])

def read_pdf(path):
    doc = fitz.open(path)
    text = ""
    for page in doc:
        text += page.get_text()
    return text.strip()

def read_txt(path):
    with open(path, 'r', encoding='utf-8') as f:
        return f.read()

def main():
    if len(sys.argv) < 2:
        print("Error: Missing prompt.")
        return

    prompt = sys.argv[1]
    file_name = sys.argv[2] if len(sys.argv) >= 3 else None

    file_text = extract_text(file_name) if file_name else ""
    full_prompt = f"{prompt}\n\nHere is the document content:\n{file_text}" if file_text else prompt

    response = llm(full_prompt)
    print(response['text'])

if __name__ == "__main__":
    main()
