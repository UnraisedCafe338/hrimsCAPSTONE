<?php
session_start();
require '../connection.php'; // Assuming this is where the connection to your DB is established
require '../vendor/autoload.php'; // Make sure the autoloader is included

use Sonata\GoogleAuthenticator\GoogleAuthenticator;
use Sonata\GoogleAuthenticator\GoogleQrUrl;

// Handle form submission for new user registration
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $gmail = $_POST['gmail']; // Get the email entered by user
    $password = $_POST['password']; // Get the password (you should hash it before storing)
    
    // Create a new OTP secret
    $g = new GoogleAuthenticator();
    $otp_secret = $g->generateSecret();

    // Insert the new user into the database
    $collection = $database->users; // Assuming 'users' is your MongoDB collection
    $collection->insertOne([
        'email' => $gmail,
        'password' => password_hash($password, PASSWORD_DEFAULT), // Store hashed password
        'otp_secret' => $otp_secret, // Store the OTP secret
    ]);
    
    // Store OTP secret in session for later use (to show QR code)
    $_SESSION['new_otp_secret'] = $otp_secret;
    $_SESSION['new_user_email'] = $gmail; // Save email for context
    $_SESSION['message'] = "Account created successfully! Please scan the QR code below to set up two-factor authentication.";

    // Redirect to the same page to display the QR code
    header("Location: register.php");
    exit();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register New Account</title>
</head>
<body>
    <h2>Register a New Account</h2>

    <form method="POST" action="register.php">
        <label for="gmail">Email:</label>
        <input type="email" id="gmail" name="gmail" required>
        <br>

        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required>
        <br>

        <button type="submit">Register</button>
    </form>

    <br>

    <?php
    // If OTP secret is in session, show QR code
    if (isset($_SESSION['new_otp_secret']) && isset($_SESSION['new_user_email'])) {
        $otp_secret = $_SESSION['new_otp_secret']; // Get the OTP secret from the session
        $user_email = $_SESSION['new_user_email']; // Get the email from the session
        
        if ($user_email) {
            // Generate the QR code URL for Google Authenticator
            $qrUrl = GoogleQrUrl::generate(
                $user_email,  // The email tied to this OTP secret
                $otp_secret,  // The OTP secret
                'HRIMS'       // Your system name
            );

            echo "<h3>Scan this QR Code (Google Authenticator)</h3>";
            echo "<img src=\"$qrUrl\" alt=\"QR Code for OTP setup\" />";
            echo "<p>{$_SESSION['message']}</p>";
        } else {
            echo "<p style='color: red;'>Error: Email is missing, QR code cannot be generated.</p>";
        }

        // Clear the session variables after showing the QR code
        unset($_SESSION['new_otp_secret']);
        unset($_SESSION['new_user_email']);
        unset($_SESSION['message']);
    }
    ?>

</body>
</html>
