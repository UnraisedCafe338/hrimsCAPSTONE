<?php
require '../vendor/autoload.php'; // MongoDB library
require '../connection.php';
$collection = $database->selectCollection("employee"); 

// 1. Yearly employment breakdown
$cursor = $collection->aggregate([
    ['$project' => [
        'year' => ['$year' => ['$dateFromString' => ['dateString' => '$date_hired']]], 
        'employment_type' => 1
    ]],
    ['$group' => [
        '_id' => ['year' => '$year', 'type' => '$employment_type'],
        'count' => ['$sum' => 1]
    ]],
]);

$yearlyStats = [];
foreach ($cursor as $row) {
    $year = $row->_id['year'] ?? 'unknown';
    $type = $row->_id['type'] ?? 'unknown';

    // Normalize case
    $type = strtolower($type);

    if (!isset($yearlyStats[$year])) {
        $yearlyStats[$year] = [];
    }

    if (!isset($yearlyStats[$year][$type])) {
        $yearlyStats[$year][$type] = 0;
    }

    $yearlyStats[$year][$type] += $row->count;
}


// 2. Teaching vs Non-Teaching
$teaching = $collection->countDocuments(['department' => 'Teaching']);
$nonTeaching = $collection->countDocuments(['department' => ['$ne' => 'Teaching']]);

// 3. Teaching full-time vs part-time
$teachingFullTime = $collection->countDocuments([
    'department' => 'Teaching',
    'employment_type' => 'Full-time'
]);
$teachingPartTime = $collection->countDocuments([
    'department' => 'Teaching',
    'employment_type' => 'Part-time'
]);

echo json_encode([
    'yearlyStats' => $yearlyStats,
    'teachingStats' => [
        'teaching' => $teaching,
        'non_teaching' => $nonTeaching
    ],
    'teachingType' => [
        'full_time' => $teachingFullTime,
        'part_time' => $teachingPartTime
    ]
]);
?>
