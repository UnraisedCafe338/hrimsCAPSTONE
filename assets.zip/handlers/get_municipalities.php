<?php
require '../vendor/autoload.php';

$provinceId = isset($_GET['province_id']) ? (int) $_GET['province_id'] : null;

require '../connection.php'; // Database connection

$collection = $client->hrims_db->municipalities;

$municipalities = $collection->find(['province_id' => $provinceId], ['sort' => ['name' => 1]]);

$result = [];
foreach ($municipalities as $mun) {
    $result[] = [
        'id' => $mun['id'],
        'name' => $mun['name'],
    ];
}

header('Content-Type: application/json');
echo json_encode($result);
