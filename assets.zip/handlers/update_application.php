<?php
require '../vendor/autoload.php';
require '../connection.php';

use MongoDB\BSON\ObjectId;

$gridFS = $database->selectGridFSBucket();

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    session_start();
    $applicantId = $_POST['applicant_id'] ?? '';

    if (!$applicantId) {
        echo json_encode(["status" => "error", "message" => "Missing applicant ID"]);
        exit;
    }

    $collection = $database->selectCollection("applicants");

    // Build update data
    $updateData = [
        "position_applied" => $_POST["position_applied"] ?? "",
        "desired_salary" => $_POST["desired_salary"] ?? "",
        "personal_info" => [
            "last_name" => $_POST["last_name"] ?? "",
            "first_name" => $_POST["first_name"] ?? "",
            "middle_name" => $_POST["middle_name"] ?? "",
            "address" => $_POST["address"] ?? "",
            "email" => $_POST["email"] ?? "",
            "contact" => $_POST["contact_no"] ?? "",
            "age" => $_POST["age"] ?? "",
            "sex" => $_POST["sex"] ?? "",
            "civil_status" => $_POST["civil_status"] ?? "",
            "birth_date" => $_POST["birth_date"] ?? "",
            "birth_place" => $_POST["birth_place"] ?? "",
            "citizen" => $_POST["citizen"] ?? "",
            "religion" => $_POST["religion"] ?? "",
            "height" => $_POST["height"] ?? "",
            "weight" => $_POST["weight"] ?? "",
            "physical_defects" => $_POST["physical_defects"] ?? ""
        ],
        "questionnaire" => [
            "description" => $_POST["description"] ?? "",
            "career_plans" => $_POST["career_plans"] ?? "",
            "reason_for_joining" => $_POST["reason_for_joining"] ?? "",
            "why_hire" => $_POST["why_hire"] ?? "",
            "expectations" => $_POST["expectations"] ?? ""
        ]
    ];
    

    // Update 2x2 picture if new one is uploaded
    if (isset($_FILES["2x2pic"]) && $_FILES["2x2pic"]["error"] === UPLOAD_ERR_OK) {
        $fileStream = fopen($_FILES["2x2pic"]["tmp_name"], 'rb');
        $photoId = $gridFS->uploadFromStream($_FILES["2x2pic"]["name"], $fileStream);
        fclose($fileStream);
        $updateData["personal_info"]["photo_id"] = (string) $photoId;
    }

    // Optional: Add new uploaded files to documents
    $documents = [];
    foreach (["resume_applicant", "training_certificates", "diploma", "contracts", "transcript_of_records"] as $fileInput) {
        if (!empty($_FILES[$fileInput]["name"][0])) {
            foreach ($_FILES[$fileInput]["name"] as $key => $name) {
                if ($_FILES[$fileInput]["error"][$key] === UPLOAD_ERR_OK) {
                    $fileStream = fopen($_FILES[$fileInput]["tmp_name"][$key], 'rb');
                    $fileId = $gridFS->uploadFromStream($name, $fileStream);
                    fclose($fileStream);
                    $documents[$fileInput][] = (string) $fileId;
                }
            }
        }
    }

    // Apply update using $set and $push for documents
    $updateQuery = ['$set' => $updateData];

    if (!empty($documents)) {
        foreach ($documents as $docType => $fileIds) {
            foreach ($fileIds as $fileId) {
                $updateQuery['$push']["documents.$docType"] = $fileId;
            }
        }
    }

    $result = $collection->updateOne(
        ['_id' => new ObjectId($applicantId)],
        $updateQuery
    );

    if ($result->getModifiedCount() > 0) {
        echo json_encode(["status" => "success", "message" => "Application updated successfully."]);
    } else {
        echo json_encode(["status" => "error", "message" => "No changes made or update failed."]);
    }

} else {
    echo json_encode(["status" => "error", "message" => "Invalid request method."]);
}
?>
