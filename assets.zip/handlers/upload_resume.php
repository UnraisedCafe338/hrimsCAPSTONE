<?php

if (isset($_FILES['resume'])) {
    $file = $_FILES['resume'];
    $filename = $file['name'];
    $filepath = $file['tmp_name'];
    $filetype = mime_content_type($filepath);

    // Read text from supported document types
    $text = '';
    if (strpos($filetype, 'pdf') !== false) {
        require_once 'vendor/autoload.php';
        $parser = new \Smalot\PdfParser\Parser();
        $pdf = $parser->parseFile($filepath);
        $text = $pdf->getText();
    } elseif (strpos($filetype, 'wordprocessingml.document') !== false || strpos($filename, '.docx') !== false) {
        $zip = new ZipArchive;
        if ($zip->open($filepath) === true) {
            $xml = $zip->getFromName('word/document.xml');
            $xml = strip_tags($xml);
            $text = $xml;
            $zip->close();
        }
    } elseif (strpos($filetype, 'text') !== false || strpos($filename, '.txt') !== false) {
        $text = file_get_contents($filepath);
    } else {
        echo json_encode(["error" => "Unsupported file type: $filetype"]);
        exit;
    }

    // Call the AI script with the extracted text
    $prompt = "You have read the uploaded document. What would you like to ask, summarize, or analyze based on this text?\n\n" . $text;

    $cmd = "python3 ai_script.py " . escapeshellarg($prompt);
    $output = shell_exec($cmd);

    echo json_encode([
        "message" => "Done reading the file. What would you like to ask, summarize, or analyze?",
        "ai_response" => trim($output)
    ]);
} else {
    echo json_encode(["error" => "No file uploaded."]);
}
?>
