<?php
require '../vendor/autoload.php'; // Include Composer's autoloader for MongoDB
require '../connection.php'; // Ensure this file has a valid MongoDB connection

use MongoDB\Client;

$gridFS = $database->selectGridFSBucket();


if ($_SERVER["REQUEST_METHOD"] === "POST") {
    session_start();

    // Capture form data
    $applicantData = [
        "position_applied" => $_POST["position_applied"] ?? "",
        "desired_salary" => $_POST["desired_salary"] ?? "",
        "status" => "Pending",
        "personal_info" => [
            "last_name" => $_POST["last_name"] ?? "",
            "first_name" => $_POST["first_name"] ?? "",
            "middle_name" => $_POST["middle_name"] ?? "",
            "address" => $_POST["address"] ?? "",
            "email" => $_POST["email"] ?? "",
            "contact" => $_POST["contact_no"] ?? "",
            "age" => $_POST["age"] ?? "",
            "sex" => $_POST["sex"] ?? "",
            "civil_status" => $_POST["civil_status"] ?? "",
            "birth_date" => $_POST["birth_date"] ?? "",
            "birth_place" => $_POST["birth_place"] ?? "",
            "citizen" => $_POST["citizen"] ?? "",
            "religion" => $_POST["religion"] ?? "",
            "height" => $_POST["height"] ?? "",
            "weight" => $_POST["weight"] ?? "",
            "physical_defects" => $_POST["physical_defects"] ?? ""
        ],
        "family_background" => [
            "father" => [
                "name" => $_POST["father_name"] ?? "",
                "occupation" => $_POST["father_occupation"] ?? ""
            ],
            "mother" => [
                "name" => $_POST["mother_name"] ?? "",
                "occupation" => $_POST["mother_occupation"] ?? ""
            ],
            "parents_address" => $_POST["parents_address"] ?? "",
            "spouse" => [
                "name" => $_POST["spouse_name"] ?? "",
                "occupation" => $_POST["spouse_occupation"] ?? ""
            ]
        ],
        "education" => [
            "college" => [
                "school" => $_POST["college"] ?? "",
                "degree" => $_POST["college_degree"] ?? ""
            ],
            "high_school" => [
                "school" => $_POST["high_school"] ?? "",
                "degree" => $_POST["high_school_degree"] ?? ""
            ],
            "elementary" => [
                "school" => $_POST["elementary"] ?? "",
                "degree" => $_POST["elementary_degree"] ?? ""
            ],
            "vocational" => [
                "school" => $_POST["vocational"] ?? "",
                "degree" => $_POST["vocational_degree"] ?? ""
            ]
        ],
        "skills" => $_POST["skills"] ?? "",
        "employment_history" => [
            "company" => $_POST["company"] ?? "",
            "position" => $_POST["position"] ?? "",
            "reason_for_leaving" => $_POST["reason_for_leaving"] ?? ""
        ],
        "emergency_contact" => [
            "name" => $_POST["ref_name"] ?? "",
            "relationship" => $_POST["emergency_relationship"] ?? "",
            "emergency_address" => $_POST["emergency_address"] ?? "",
            "emergency_number" => $_POST["emergency_number"] ?? ""

        ],
        "character_reference" => [
            "name" => $_POST["ref_name"] ?? "",
            "company" => $_POST["ref_company"] ?? "",
            "position" => $_POST["ref_position"] ?? "",
            "contact" => $_POST["ref_contact"] ?? ""
        ],
        "documents" => [],
        "questionnaire" => [
            "description" => $_POST["description"] ?? "",
            "career_plans" => $_POST["career_plans"] ?? "",
            "reason_for_joining" => $_POST["reason_for_joining"] ?? "",
            "why_hire" => $_POST["why_hire"] ?? "",
            "expectations" => $_POST["expectations"] ?? ""
        ]
    ];

   // Handle file uploads
   if (!empty($_FILES)) {
    foreach (["resume_applicant", "training_certificates", "diploma", "contracts", "transcript_of_records"] as $fileInput) {
        if (!empty($_FILES[$fileInput]["name"][0])) {
            $applicantData['documents'][$fileInput] = [];
            
            foreach ($_FILES[$fileInput]["name"] as $key => $name) {
                if ($_FILES[$fileInput]["error"][$key] === UPLOAD_ERR_OK) {
                    $tmpName = $_FILES[$fileInput]["tmp_name"][$key];
                    
                    if (is_uploaded_file($tmpName) && file_exists($tmpName)) {
                        $contentType = mime_content_type($tmpName) ?? 'application/octet-stream';
                        
                        $fileStream = fopen($tmpName, 'rb');
                        $fileId = $gridFS->uploadFromStream($name, $fileStream, [
                            'metadata' => [
                                'mimeType' => $contentType,
                                'originalName' => $name
                            ]
                        ]);
                        fclose($fileStream);

                        $applicantData['documents'][$fileInput][] = (string) $fileId;
                    }
                }
            }
        }
    }
}

    // Upload 2x2 applicant photo
    if ($_FILES["2x2pic"]["error"] === UPLOAD_ERR_OK) {
        $fileStream = fopen($_FILES["2x2pic"]["tmp_name"], 'rb');
        if ($fileStream) {
            $fileId = $gridFS->uploadFromStream($_FILES["2x2pic"]["name"], $fileStream);
            fclose($fileStream);
            $applicantData['personal_info']['photo_id'] = (string) $fileId;
        } else {
            error_log("Failed to open file stream.");
        }
    } else {
        error_log("File upload error: " . $_FILES["2x2pic"]["error"]);
    }
    

    // Insert data into MongoDB
    $collection = $database->selectCollection("applicants");
    $insertResult = $collection->insertOne($applicantData);

    if ($insertResult->getInsertedCount() > 0) {
        echo json_encode(["status" => "success", "message" => "Application submitted successfully."]);
    } else {
        echo json_encode(["status" => "error", "message" => "Failed to submit application."]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "Invalid request method."]);
}
?>
